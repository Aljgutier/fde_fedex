"""
Challenge 3: Workflow Integration Tests

Exercise realistic end-to-end conversation flows, tool-call sequences,
concurrency, and edge cases against the simulated backends.
"""

import pytest
import asyncio
from mocks import create_test_agent


@pytest.mark.asyncio
async def test_complete_workflow():
    """Test complete customer service workflow."""

    # Simulate multi-turn conversation
    responses = [
        "I'd be happy to help with your order. Could you provide your order ID?",
        "Let me check the status of order ORD-123.",
        "Your order has been shipped with tracking number TRACK-ORD-123.",
    ]

    agent = create_test_agent(responses)

    # Turn 1: Initial request
    result1 = await agent.run("I have a question about my order")
    assert "order ID" in result1.output.lower() or "order" in result1.output.lower()

    # Turn 2: Provide order ID (chain history from previous turn)
    result2 = await agent.run("It's ORD-123", message_history=result1.new_messages())
    assert "check" in result2.output.lower() or "status" in result2.output.lower()

    # Turn 3: Get final response
    result3 = await agent.run("Thanks", message_history=result2.new_messages())
    assert "shipped" in result3.output.lower() or "TRACK" in result3.output


@pytest.mark.asyncio
async def test_tool_call_integration():
    """Test integration with tool calling."""
    tool_calls = [{"name": "get_order_status", "args": {"order_id": "ORD-123"}}]

    agent = create_test_agent(tool_calls=tool_calls)

    result = await agent.run("Check order ORD-123")

    assert result.output is not None
    assert len(result.output) > 0


@pytest.mark.asyncio
async def test_multiple_tool_calls_sequence():
    """Test multiple tool calls in sequence."""
    # First query uses one tool
    agent1 = create_test_agent(
        tool_calls=[{"name": "get_order_status", "args": {"order_id": "ORD-123"}}]
    )

    result1 = await agent1.run("Check order")
    assert result1.output is not None

    # Second query uses different tool
    agent2 = create_test_agent(
        tool_calls=[
            {
                "name": "create_ticket",
                "args": {"issue": "Problem", "priority": "urgent"},
            }
        ]
    )

    result2 = await agent2.run("Report problem")
    assert result2.output is not None


@pytest.mark.slow
@pytest.mark.asyncio
async def test_stress_concurrent_queries():
    """Test agent handles concurrent queries."""
    agent = create_test_agent(["Response"] * 10)

    tasks = [agent.run(f"Query {i}") for i in range(10)]
    results = await asyncio.gather(*tasks)

    assert len(results) == 10
    assert all(r.output == "Response" for r in results)


@pytest.mark.asyncio
async def test_edge_case_very_long_query():
    """Test agent handles very long input."""
    agent = create_test_agent("Understood, I've received your message.")

    long_query = "word " * 1000  # 1000 words
    result = await agent.run(long_query)

    assert result.output == "Understood, I've received your message."


@pytest.mark.asyncio
async def test_edge_case_special_characters():
    """Test agent handles queries with special characters."""
    agent = create_test_agent("Processed your query successfully.")

    special_query = "Order #123-456 @ user@email.com & Product <special>"
    result = await agent.run(special_query)

    assert result.output is not None


@pytest.mark.asyncio
async def test_error_recovery():
    """Test agent recovers from errors gracefully."""
    responses = [
        "Sorry, I encountered an error. Let me try again.",
        "Here's your information.",
    ]

    agent = create_test_agent(responses)

    result1 = await agent.run("Query that fails")
    assert "error" in result1.output.lower()

    result2 = await agent.run("Retry query")
    assert "information" in result2.output.lower()


@pytest.mark.asyncio
async def test_timeout_simulation():
    """Test agent behavior with simulated timeout."""
    agent = create_test_agent("Quick response")

    try:
        result = await asyncio.wait_for(agent.run("Query"), timeout=5.0)
        assert result.output == "Quick response"
    except asyncio.TimeoutError:
        pytest.fail("Query timed out unexpectedly")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
