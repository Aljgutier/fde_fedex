"""
PyTest Configuration
"""

import pytest

# Import fixtures
pytest_plugins = ["fixtures"]


def pytest_configure(config):
    """Configure pytest markers."""
    config.addinivalue_line(
        "markers", "slow: marks tests as slow (deselect with '-m \"not slow\"')"
    )
    config.addinivalue_line("markers", "integration: marks tests as integration tests")
    config.addinivalue_line("markers", "unit: marks tests as unit tests")


def pytest_collection_modifyitems(config, items):
    """Automatically mark tests based on file name.

    `challenge3_*.py` files are matched in addition to the canonical
    `test_integration*` glob so that `uv run pytest -m integration -v`
    actually collects Challenge 3's tests. Without this, the marker
    auto-applier silently skipped Challenge 3 (the test file's nodeid
    didn't match `test_integration`), and the documented validation
    command `uv run pytest -m integration -v` collected zero tests with
    no failure signal — making Challenge 3's validation pass vacuously.
    """
    for item in items:
        # Mark integration tests
        if "test_integration" in item.nodeid or "challenge3" in item.nodeid:
            item.add_marker(pytest.mark.integration)

        # Mark unit tests
        if "test_tools" in item.nodeid or "test_agent" in item.nodeid:
            item.add_marker(pytest.mark.unit)
