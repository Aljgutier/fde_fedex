"""
Challenge 1: Golden Dataset Testing

Regression testing with expected query-response pairs.
Detects when changes break previously working scenarios.
"""

import pytest
import json
from pathlib import Path
from dataclasses import dataclass
from typing import List
from mocks import create_test_agent


@dataclass
class GoldenExample:
    """A golden example for regression testing."""

    query: str
    expected_response: str
    category: str
    description: str


# Golden dataset - example queries with expected responses
GOLDEN_DATASET = [
    GoldenExample(
        query="What's the status of order ORD-123?",
        expected_response="shipped",
        category="order_status",
        description="Check order status query",
    ),
    GoldenExample(
        query="I need help with my order",
        expected_response="order",
        category="general_inquiry",
        description="General order inquiry",
    ),
    GoldenExample(
        query="How do I return a product?",
        expected_response="return",
        category="returns",
        description="Return policy question",
    ),
    GoldenExample(
        query="Create a ticket for damaged item",
        expected_response="ticket",
        category="ticket_creation",
        description="Ticket creation request",
    ),
    GoldenExample(
        query="Where is my package?",
        expected_response="track",
        category="tracking",
        description="Package tracking query",
    ),
]


class GoldenDatasetTester:
    """Test agent against golden dataset."""

    def __init__(self, dataset: List[GoldenExample]):
        self.dataset = dataset
        self.results = []

    async def run_tests(self, agent) -> dict:
        """Run all golden dataset tests."""
        passed = 0
        failed = 0

        for example in self.dataset:
            result = await self.test_example(agent, example)
            self.results.append(result)

            if result["passed"]:
                passed += 1
            else:
                failed += 1

        return {
            "total": len(self.dataset),
            "passed": passed,
            "failed": failed,
            "pass_rate": passed / len(self.dataset) if self.dataset else 0,
            "results": self.results,
        }

    async def test_example(self, agent, example: GoldenExample) -> dict:
        """Test a single golden example."""
        try:
            result = await agent.run(example.query)
            response = result.output.lower()

            # Check if expected keywords are in response
            passed = example.expected_response.lower() in response

            return {
                "query": example.query,
                "category": example.category,
                "description": example.description,
                "expected": example.expected_response,
                "actual": result.output,
                "passed": passed,
                "error": None,
            }
        except Exception as e:
            return {
                "query": example.query,
                "category": example.category,
                "description": example.description,
                "expected": example.expected_response,
                "actual": None,
                "passed": False,
                "error": str(e),
            }

    def save_results(self, filepath: Path):
        """Save test results to JSON."""
        with open(filepath, "w") as f:
            json.dump(self.results, f, indent=2)

    def load_results(self, filepath: Path) -> List[dict]:
        """Load previous test results."""
        with open(filepath, "r") as f:
            return json.load(f)

    def compare_with_baseline(self, baseline_filepath: Path) -> dict:
        """Compare current results with baseline."""
        baseline = self.load_results(baseline_filepath)

        regressions = []
        improvements = []

        for current, baseline_item in zip(self.results, baseline):
            if current["passed"] and not baseline_item["passed"]:
                improvements.append(current)
            elif not current["passed"] and baseline_item["passed"]:
                regressions.append(current)

        return {
            "regressions": regressions,
            "improvements": improvements,
            "regression_count": len(regressions),
            "improvement_count": len(improvements),
        }


# PyTest tests using golden dataset


@pytest.mark.asyncio
async def test_golden_dataset_order_status():
    """Test order status queries from golden dataset."""
    examples = [ex for ex in GOLDEN_DATASET if ex.category == "order_status"]

    for example in examples:
        agent = create_test_agent(f"Your order is {example.expected_response}")
        result = await agent.run(example.query)

        assert (
            example.expected_response.lower() in result.output.lower()
        ), f"Expected '{example.expected_response}' in response for: {example.query}"


@pytest.mark.asyncio
async def test_golden_dataset_all():
    """Run complete golden dataset test suite."""
    tester = GoldenDatasetTester(GOLDEN_DATASET)

    # Create agent with responses that match expectations
    responses = [
        "Your order is shipped",
        "I can help with your order",
        "You can return products within 30 days",
        "I'll create a ticket for you",
        "Let me track your package",
    ]

    agent = create_test_agent(responses)

    results = await tester.run_tests(agent)

    # Should pass most tests
    assert (
        results["pass_rate"] >= 0.6
    ), f"Pass rate {results['pass_rate']:.1%} below 60%"


@pytest.mark.asyncio
async def test_golden_dataset_regression_detection():
    """Test regression detection capability."""
    tester = GoldenDatasetTester(GOLDEN_DATASET[:3])

    # First version passes
    agent_v1 = create_test_agent(["shipped", "order help", "return policy"])

    results_v1 = await tester.run_tests(agent_v1)

    # Save baseline
    baseline_path = Path("golden_baseline.json")
    tester.save_results(baseline_path)

    # Second version has regression
    tester2 = GoldenDatasetTester(GOLDEN_DATASET[:3])
    agent_v2 = create_test_agent(
        [
            "unknown",  # Regression: doesn't mention shipped
            "order help",
            "return policy",
        ]
    )

    results_v2 = await tester2.run_tests(agent_v2)

    # Compare
    comparison = tester2.compare_with_baseline(baseline_path)

    # Should detect regression
    assert comparison["regression_count"] > 0

    # Cleanup
    baseline_path.unlink()


@pytest.mark.asyncio
async def test_fuzzy_matching():
    """Test fuzzy matching for golden dataset."""
    agent = create_test_agent("Your order has been successfully shipped")

    example = GoldenExample(
        query="Order status?",
        expected_response="shipped",
        category="order_status",
        description="Test",
    )

    result = await agent.run(example.query)

    # Fuzzy match - should contain expected word
    assert example.expected_response.lower() in result.output.lower()


if __name__ == "__main__":
    import asyncio

    async def demo():
        print("Golden Dataset Testing Demo\n")
        print("=" * 60)

        tester = GoldenDatasetTester(GOLDEN_DATASET)

        # Create agent with reasonable responses
        responses = [
            "Your order is shipped",
            "I can help with your order",
            "You can return products",
            "Creating a ticket",
            "Tracking your package",
        ]

        agent = create_test_agent(responses)

        results = await tester.run_tests(agent)

        print(f"\nResults:")
        print(f"Total: {results['total']}")
        print(f"Passed: {results['passed']}")
        print(f"Failed: {results['failed']}")
        print(f"Pass Rate: {results['pass_rate']:.1%}")

        print(f"\nDetailed Results:")
        for r in results["results"]:
            status = "✓" if r["passed"] else "✗"
            print(f"{status} [{r['category']}] {r['description']}")

    asyncio.run(demo())

    # Run pytest
    pytest.main([__file__, "-v"])
