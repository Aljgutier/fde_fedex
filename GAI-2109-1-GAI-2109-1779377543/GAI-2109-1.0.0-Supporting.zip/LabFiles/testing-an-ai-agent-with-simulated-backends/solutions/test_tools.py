"""
Tool Tests - Unit tests for agent tools
"""

import pytest
from pydantic_ai import RunContext
from pydantic_ai.models.test import TestModel
from pydantic_ai.usage import RunUsage
from agent import get_order_status, create_ticket


def make_ctx():
    """Create a RunContext for testing tools directly."""
    return RunContext(
        deps=None,
        retry=0,
        messages=[],
        model=TestModel(),
        usage=RunUsage(),
    )


@pytest.mark.asyncio
async def test_get_order_status_success():
    """Test order status tool with a valid, known order ID (ORD-123).

    Assert the returned OrderStatus has:
      - order_id == "ORD-123"
      - status   == "shipped"
      - tracking_number == "TRACK-ORD-123"
    """
    ctx = make_ctx()
    # YOUR CODE HERE
    # [SOLUTION]
    result = await get_order_status(ctx, "ORD-123")

    assert result.order_id == "ORD-123"
    assert result.status == "shipped"
    assert result.tracking_number == "TRACK-ORD-123"
    # [/SOLUTION]


@pytest.mark.asyncio
async def test_get_order_status_processing():
    """Test order with processing status."""
    ctx = make_ctx()

    result = await get_order_status(ctx, "ORD-456")

    assert result.order_id == "ORD-456"
    assert result.status == "processing"
    assert result.tracking_number.startswith("TRACK-")


@pytest.mark.asyncio
async def test_get_order_status_not_found():
    """Test order status tool with unknown order."""
    ctx = make_ctx()

    result = await get_order_status(ctx, "ORD-999")

    assert result.order_id == "ORD-999"
    assert result.status == "not_found"
    assert result.tracking_number == ""


@pytest.mark.asyncio
async def test_get_order_status_empty_id():
    """Test order status tool rejects empty order ID."""
    ctx = make_ctx()

    with pytest.raises(ValueError, match="Order ID cannot be empty"):
        await get_order_status(ctx, "")


@pytest.mark.asyncio
async def test_get_order_status_whitespace_only():
    """Test order status tool rejects whitespace-only ID."""
    ctx = make_ctx()

    with pytest.raises(ValueError, match="Order ID cannot be empty"):
        await get_order_status(ctx, "   ")


@pytest.mark.asyncio
async def test_create_ticket_default_priority():
    """Test ticket creation with default priority."""
    ctx = make_ctx()

    result = await create_ticket(ctx, "Product is damaged")

    assert "ticket_id" in result
    assert result["ticket_id"].startswith("TICKET-")
    assert result["issue"] == "Product is damaged"
    assert result["priority"] == "normal"
    assert result["status"] == "open"


@pytest.mark.asyncio
async def test_create_ticket_urgent_priority():
    """Test ticket creation with urgent priority."""
    ctx = make_ctx()

    result = await create_ticket(ctx, "Service outage", priority="urgent")

    assert result["priority"] == "urgent"
    assert result["status"] == "open"
    assert result["issue"] == "Service outage"


@pytest.mark.asyncio
async def test_create_ticket_invalid_priority():
    """Test ticket creation normalizes invalid priority."""
    ctx = make_ctx()

    result = await create_ticket(ctx, "General question", priority="super-duper")

    # Should default to normal
    assert result["priority"] == "normal"


@pytest.mark.asyncio
async def test_create_ticket_empty_issue():
    """Test ticket creation rejects empty issue."""
    ctx = make_ctx()

    with pytest.raises(ValueError, match="Issue description cannot be empty"):
        await create_ticket(ctx, "")


@pytest.mark.asyncio
async def test_create_ticket_unique_ids():
    """Test that each ticket gets unique ID."""
    ctx = make_ctx()

    result1 = await create_ticket(ctx, "Issue 1")
    result2 = await create_ticket(ctx, "Issue 2")

    assert result1["ticket_id"] != result2["ticket_id"]


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
