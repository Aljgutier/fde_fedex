# Testing AI Agent - Solution

Comprehensive test suite for AI agents with simulated backends.

## Structure

- `agent.py` - Customer support agent under test
- `mocks.py` - Simulated model backends
- `test_agent.py` - Agent behavior tests
- `test_tools.py` - Tool unit tests
- `test_integration.py` - Workflow integration tests
- `fixtures.py` - Reusable test fixtures
- `conftest.py` - PyTest configuration
- `challenge1_solution.py` - Golden dataset testing
- `challenge2_solution.py` - Performance testing

## Quick Start

```bash
cp .env.example .env
uv sync
uv run pytest -v
```

## Run Specific Tests

```bash
# Unit tests only
uv run pytest -m unit

# Integration tests
uv run pytest -m integration

# Exclude slow tests
uv run pytest -m "not slow"

# Specific test file
uv run pytest test_agent.py -v

# With coverage
uv run pytest --cov=agent --cov-report=html
```

## Features

- Deterministic testing with fake models
- No API costs during testing
- Fast execution (<1s per test)
- Tool call validation
- Edge case coverage
- Performance monitoring
- Golden dataset regression tests

Educational use - GAI-2109.
