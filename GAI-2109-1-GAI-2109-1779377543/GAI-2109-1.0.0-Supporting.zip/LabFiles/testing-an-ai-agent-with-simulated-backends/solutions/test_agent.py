"""
Agent Tests - Testing agent behavior with simulated backends
"""

import pytest
from mocks import create_test_agent, FakeModel
from agent import support_agent


@pytest.mark.asyncio
async def test_simple_response():
    """Build an agent with a single scripted response and assert the output.

    Steps:
      1. Use create_test_agent("Thank you for contacting support!") to build
         an agent that returns exactly that text.
      2. await agent.run("Hello") and capture the result.
      3. Assert result.output equals the scripted response.
    """
    # YOUR CODE HERE
    # [SOLUTION]
    agent = create_test_agent("Thank you for contacting support!")

    result = await agent.run("Hello")

    assert result.output == "Thank you for contacting support!"
    # [/SOLUTION]


@pytest.mark.asyncio
async def test_multiple_queries():
    """Test agent handles multiple queries with different responses."""
    agent = create_test_agent(["First response", "Second response", "Third response"])

    result1 = await agent.run("Query 1")
    result2 = await agent.run("Query 2")
    result3 = await agent.run("Query 3")

    assert result1.output == "First response"
    assert result2.output == "Second response"
    assert result3.output == "Third response"


@pytest.mark.asyncio
async def test_tool_call_simulation():
    """Simulate a tool call and validate the agent's final output.

    This is the core insight of the lab: you can script tool calls so the
    agent's plumbing (tool dispatch, result feedback) is exercised
    deterministically, with no real LLM involved.

    Steps:
      1. Define tool_calls as a list with a single dict:
             {"name": "get_order_status", "args": {"order_id": "ORD-123"}}
      2. Build the agent via create_test_agent(tool_calls=tool_calls).
      3. await agent.run("What's the status of order ORD-123?").
      4. Assert result.output is not None and contains "information"
         (case-insensitive) — the scripted reply after the tool runs.
    """
    # YOUR CODE HERE
    # [SOLUTION]
    tool_calls = [{"name": "get_order_status", "args": {"order_id": "ORD-123"}}]

    agent = create_test_agent(tool_calls=tool_calls)

    result = await agent.run("What's the status of order ORD-123?")

    assert result.output is not None
    assert "information" in result.output.lower()
    # [/SOLUTION]


@pytest.mark.asyncio
async def test_call_counting():
    """Track number of model calls via FakeModel.call_count."""
    fake_model = FakeModel(["Response"])

    from pydantic_ai import Agent

    test_agent = Agent(
        fake_model.model,
        system_prompt=support_agent._system_prompts[0],
    )

    await test_agent.run("Query 1")
    await test_agent.run("Query 2")
    await test_agent.run("Query 3")

    assert fake_model.call_count == 3


@pytest.mark.asyncio
async def test_message_history_inspection():
    """Inspect messages sent to the fake model."""
    fake_model = FakeModel(["Response"])

    from pydantic_ai import Agent

    test_agent = Agent(
        fake_model.model,
        system_prompt=support_agent._system_prompts[0],
    )

    await test_agent.run("What is the weather?")

    assert len(fake_model.received_messages) > 0


@pytest.mark.asyncio
async def test_empty_query_handling():
    """Agent handles empty queries gracefully."""
    agent = create_test_agent("Please provide more information.")

    result = await agent.run("")

    assert result.output is not None
    assert len(result.output) > 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
