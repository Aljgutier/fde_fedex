"""
PyTest Fixtures - Reusable test components
"""

import pytest
from mocks import create_test_agent


@pytest.fixture
def simple_agent():
    """Agent with simple response."""
    return create_test_agent("Test response")


@pytest.fixture
def multi_response_agent():
    """Agent with multiple predefined responses."""
    return create_test_agent(["First response", "Second response", "Third response"])


@pytest.fixture
def tool_calling_agent():
    """Agent that calls tools."""
    return create_test_agent(
        tool_calls=[{"name": "get_order_status", "args": {"order_id": "TEST-123"}}]
    )


@pytest.fixture
def error_agent():
    """Agent that returns error messages."""
    return create_test_agent("An error occurred while processing your request.")


@pytest.fixture
def polite_agent():
    """Agent with polite, professional responses."""
    return create_test_agent(
        [
            "Thank you for contacting us.",
            "I'd be happy to help with that.",
            "Is there anything else I can assist you with?",
        ]
    )


@pytest.fixture
def sample_orders():
    """Sample order data for tests."""
    return [
        {"id": "ORD-001", "status": "shipped", "tracking": "TRACK-001"},
        {"id": "ORD-002", "status": "processing", "tracking": "TRACK-002"},
        {"id": "ORD-003", "status": "delivered", "tracking": "TRACK-003"},
    ]


@pytest.fixture
def sample_tickets():
    """Sample ticket data for tests."""
    return [
        {"id": "TICKET-001", "issue": "Damaged product", "priority": "urgent"},
        {"id": "TICKET-002", "issue": "Wrong item", "priority": "normal"},
        {"id": "TICKET-003", "issue": "Delayed delivery", "priority": "normal"},
    ]


@pytest.fixture
def test_queries():
    """Common test queries."""
    return [
        "What's the status of my order?",
        "I need to report a problem.",
        "How do I return an item?",
        "Where is my package?",
        "I have a question about my order.",
    ]


@pytest.fixture
def edge_case_queries():
    """Edge case test queries."""
    return [
        "",  # Empty query
        "   ",  # Whitespace only
        "word " * 1000,  # Very long query
        "Order #123-456 <special>",  # Special characters
        "🚀 Emoji query 🎉",  # Unicode/emoji
    ]
