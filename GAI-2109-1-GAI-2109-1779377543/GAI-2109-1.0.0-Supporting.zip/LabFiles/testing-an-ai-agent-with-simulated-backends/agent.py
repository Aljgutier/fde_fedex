"""
Customer Support Agent - Under Test
Demonstrates agent with tools for testing purposes
"""

from pydantic_ai import Agent, RunContext
from pydantic import BaseModel
from dotenv import load_dotenv
import os

load_dotenv()


class OrderStatus(BaseModel):
    """Order status details."""

    order_id: str
    status: str
    tracking_number: str


# Simulated database
ORDERS = {
    "ORD-123": {"status": "shipped", "tracking": "TRACK-ORD-123"},
    "ORD-456": {"status": "processing", "tracking": "TRACK-ORD-456"},
    "ORD-789": {"status": "delivered", "tracking": "TRACK-ORD-789"},
}

support_agent = Agent(
    os.getenv("AI_MODEL", "openai:gpt-5.4-mini"),
    system_prompt="""You are a customer support agent.
    Help customers with orders and issues.
    Use tools when needed to look up information.""",
)


@support_agent.tool
async def get_order_status(ctx: RunContext[None], order_id: str) -> OrderStatus:
    """
    Get status of a customer order.

    Args:
        order_id: The order ID to look up (e.g., 'ORD-123')

    Returns:
        OrderStatus with order details

    Raises:
        ValueError: If order_id is empty or not found
    """
    if not order_id or not order_id.strip():
        raise ValueError("Order ID cannot be empty")

    # Simulated database lookup
    if order_id in ORDERS:
        order_data = ORDERS[order_id]
        return OrderStatus(
            order_id=order_id,
            status=order_data["status"],
            tracking_number=order_data["tracking"],
        )

    # For testing - create mock data for unknown orders
    return OrderStatus(order_id=order_id, status="not_found", tracking_number="")


@support_agent.tool
async def create_ticket(
    ctx: RunContext[None], issue: str, priority: str = "normal"
) -> dict:
    """
    Create a support ticket.

    Args:
        issue: Description of the issue
        priority: Priority level (normal, urgent, critical)

    Returns:
        Dictionary with ticket details

    Raises:
        ValueError: If issue is empty
    """
    if not issue or not issue.strip():
        raise ValueError("Issue description cannot be empty")

    if priority not in ["normal", "urgent", "critical"]:
        priority = "normal"

    # Simulated ticket creation
    import uuid

    ticket_id = f"TICKET-{uuid.uuid4().hex[:8].upper()}"

    return {
        "ticket_id": ticket_id,
        "issue": issue,
        "priority": priority,
        "status": "open",
        "created_at": "timestamp",
    }


async def handle_query(query: str) -> str:
    """
    Process customer query.

    Args:
        query: Customer question or request

    Returns:
        Agent response
    """
    result = await support_agent.run(query)
    return result.output


if __name__ == "__main__":
    import asyncio

    async def demo():
        print("Customer Support Agent Demo\n")

        # Test order status
        result1 = await handle_query("What's the status of order ORD-123?")
        print(f"Query: What's the status of order ORD-123?")
        print(f"Response: {result1}\n")

        # Test ticket creation
        result2 = await handle_query("I need help with a damaged product")
        print(f"Query: I need help with a damaged product")
        print(f"Response: {result2}\n")

    asyncio.run(demo())
