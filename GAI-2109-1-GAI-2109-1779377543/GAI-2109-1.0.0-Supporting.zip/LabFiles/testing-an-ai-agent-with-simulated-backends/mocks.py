"""
Mock Backends for Testing
Provides simulated models and test helpers using pydantic-ai's TestModel and FunctionModel
"""

from typing import Any, Optional
from pydantic_ai import Agent
from pydantic_ai.models.test import TestModel
from pydantic_ai.models.function import FunctionModel
from pydantic_ai.messages import (
    ModelMessage,
    ModelRequest,
    ModelResponse,
    TextPart,
    ToolCallPart,
    ToolReturnPart,
)
from pydantic_ai.models import ModelRequestParameters, RequestUsage


class FakeModel:
    """Simulated model for deterministic testing using FunctionModel."""

    def __init__(self, responses: list[str] | None = None):
        """
        Args:
            responses: Predefined responses to return in sequence
        """
        self.responses = responses or ["Default test response"]
        self.call_count = 0
        self.received_messages: list[list[ModelMessage]] = []

        # Create the underlying FunctionModel
        self._model = FunctionModel(self._handle_request, model_name="fake-model")

    def _handle_request(
        self,
        messages: list[ModelMessage],
        model_settings: Any = None,
    ) -> ModelResponse:
        """Return predefined response."""
        self.received_messages.append(messages)
        response_text = self.responses[min(self.call_count, len(self.responses) - 1)]
        self.call_count += 1
        return ModelResponse(parts=[TextPart(content=response_text)])

    @property
    def model(self):
        return self._model

    def name(self) -> str:
        return "fake-model"


class ToolCallingFakeModel:
    """Simulated model that makes tool calls using FunctionModel."""

    def __init__(self, tool_calls: list[dict]):
        """
        Args:
            tool_calls: Tool calls to simulate
            Example: [{'name': 'get_order_status', 'args': {'order_id': '123'}}]
        """
        self.tool_calls = tool_calls
        self.call_count = 0
        self.received_messages: list[list[ModelMessage]] = []

        self._model = FunctionModel(
            self._handle_request, model_name="fake-tool-calling-model"
        )

    def _handle_request(
        self,
        messages: list[ModelMessage],
        model_settings: Any = None,
    ) -> ModelResponse:
        """Return tool call or final response."""
        self.received_messages.append(messages)

        # Check if we have tool return in messages
        has_tool_return = any(
            isinstance(msg, ModelRequest)
            and any(isinstance(part, ToolReturnPart) for part in msg.parts)
            for msg in messages
        )

        if not has_tool_return and self.call_count == 0:
            # First call: request tool
            tool_call = self.tool_calls[0] if self.tool_calls else {}
            self.call_count += 1

            return ModelResponse(
                parts=[
                    ToolCallPart(
                        tool_name=tool_call.get("name", "unknown"),
                        args=tool_call.get("args", {}),
                        tool_call_id="call_001",
                    )
                ]
            )
        else:
            # After tool execution: provide final response
            return ModelResponse(
                parts=[TextPart(content="Here is the information you requested.")]
            )

    @property
    def model(self):
        return self._model

    def name(self) -> str:
        return "fake-tool-calling-model"


def create_test_agent(
    response: str | list[str] | None = None, tool_calls: list[dict] | None = None
):
    """
    Create agent with fake backend for testing.

    Args:
        response: Single response or list of responses for multiple calls
        tool_calls: Tool calls to simulate [(name, args), ...]

    Returns:
        Agent instance with fake model injected
    """
    from agent import support_agent

    # Create fake model
    if tool_calls:
        fake = ToolCallingFakeModel(tool_calls)
    else:
        responses = (
            response if isinstance(response, list) else [response] if response else None
        )
        fake = FakeModel(responses)

    # Create new agent with fake model, preserving system prompt and tools
    test_agent = Agent(
        fake.model,
        system_prompt="""You are a customer support agent.
    Help customers with orders and issues.
    Use tools when needed to look up information.""",
    )

    # Copy tools from original agent
    test_agent._function_toolset.tools = dict(support_agent._function_toolset.tools)

    return test_agent


def create_fake_model(responses: list[str]) -> FakeModel:
    """Create a fake model with predefined responses."""
    return FakeModel(responses)


def create_tool_calling_fake_model(tool_calls: list[dict]) -> ToolCallingFakeModel:
    """Create a fake model that makes tool calls."""
    return ToolCallingFakeModel(tool_calls)
