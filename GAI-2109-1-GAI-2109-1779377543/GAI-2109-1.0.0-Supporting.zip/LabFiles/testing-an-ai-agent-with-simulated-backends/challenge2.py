"""
Challenge 2: Performance Test Suite

Measure and enforce performance requirements (latency, token usage, cost).
"""

import pytest
import asyncio
import time
from dataclasses import dataclass
from typing import List
from mocks import create_test_agent, FakeModel


@dataclass
class PerformanceMetrics:
    """Performance metrics for a test run."""

    query: str
    latency_ms: float
    tokens_used: int
    success: bool
    error: str | None = None


class PerformanceMonitor:
    """Monitor and track performance metrics."""

    def __init__(
        self,
        max_latency_ms: float = 1000,
        max_tokens: int = 500,
        max_cost_per_query: float = 0.01,
    ):
        self.max_latency_ms = max_latency_ms
        self.max_tokens = max_tokens
        self.max_cost_per_query = max_cost_per_query
        self.metrics: List[PerformanceMetrics] = []

    async def measure_query(self, agent, query: str) -> PerformanceMetrics:
        """Measure performance of a single query."""
        start_time = time.time()

        try:
            result = await agent.run(query)
            end_time = time.time()

            latency_ms = (end_time - start_time) * 1000
            # In pydantic-ai 1.x, `result.usage` is a method (not an
            # attribute) — call it. The pre-fix code passed it through
            # getattr-with-default, which returned the bound method
            # itself; reading `.total_tokens` off the method raised
            # AttributeError that was then swallowed by the outer except,
            # silently recording success=False on every call (zero token
            # collection across the suite).
            usage = result.usage()
            tokens_used = usage.total_tokens if usage is not None else 0

            metric = PerformanceMetrics(
                query=query,
                latency_ms=latency_ms,
                tokens_used=tokens_used,
                success=True,
            )

        except Exception as e:
            end_time = time.time()
            latency_ms = (end_time - start_time) * 1000

            metric = PerformanceMetrics(
                query=query,
                latency_ms=latency_ms,
                tokens_used=0,
                success=False,
                error=str(e),
            )

        self.metrics.append(metric)
        return metric

    def check_sla_compliance(self, metric: PerformanceMetrics) -> dict:
        """Check if metric meets SLA requirements."""
        return {
            "latency_ok": metric.latency_ms <= self.max_latency_ms,
            "tokens_ok": metric.tokens_used <= self.max_tokens,
            "success_ok": metric.success,
            "overall_ok": (
                metric.latency_ms <= self.max_latency_ms
                and metric.tokens_used <= self.max_tokens
                and metric.success
            ),
        }

    def get_summary(self) -> dict:
        """Get summary statistics."""
        if not self.metrics:
            return {}

        latencies = [m.latency_ms for m in self.metrics]
        tokens = [m.tokens_used for m in self.metrics]
        successes = sum(1 for m in self.metrics if m.success)

        return {
            "total_queries": len(self.metrics),
            "successful_queries": successes,
            "success_rate": successes / len(self.metrics),
            "avg_latency_ms": sum(latencies) / len(latencies),
            "max_latency_ms": max(latencies),
            "min_latency_ms": min(latencies),
            "avg_tokens": sum(tokens) / len(tokens) if tokens else 0,
            "max_tokens": max(tokens) if tokens else 0,
            "total_tokens": sum(tokens),
        }

    def get_violations(self) -> List[dict]:
        """Get all SLA violations."""
        violations = []

        for metric in self.metrics:
            compliance = self.check_sla_compliance(metric)

            if not compliance["overall_ok"]:
                violations.append(
                    {
                        "query": metric.query,
                        "latency_ms": metric.latency_ms,
                        "tokens_used": metric.tokens_used,
                        "latency_violation": not compliance["latency_ok"],
                        "tokens_violation": not compliance["tokens_ok"],
                        "error": metric.error,
                    }
                )

        return violations


# PyTest tests for performance


@pytest.mark.asyncio
async def test_latency_requirement():
    """Test that queries complete within latency requirement."""
    monitor = PerformanceMonitor(max_latency_ms=100)
    agent = create_test_agent("Quick response")

    metric = await monitor.measure_query(agent, "Test query")

    assert (
        metric.latency_ms < monitor.max_latency_ms
    ), f"Latency {metric.latency_ms:.1f}ms exceeds {monitor.max_latency_ms}ms"


@pytest.mark.asyncio
async def test_token_usage_limit():
    """Test that queries stay within token limit.

    Uses the public Agent.override(model=...) API to swap in a
    deterministic backend for the duration of the test, rather than
    constructing a fresh Agent from the FakeModel directly. The
    pre-fix code did `Agent(fake_model, system_prompt=support_agent.system_prompt())`,
    which raised two TypeErrors against pydantic-ai 1.x:

    * `Agent(fake_model, ...)` — `infer_model(fake_model)` tried to
      iterate the FakeModel wrapper as a string and raised
      `argument of type 'FakeModel' is not iterable`.
    * `support_agent.system_prompt()` — `system_prompt` is a registered
      callable inside the agent's prompt registry, not a public method;
      calling it directly raised `'function' object is not iterable`.

    `Agent.override(model=...)` is the documented mocking API and
    sidesteps both errors.
    """
    from agent import support_agent

    fake_model = FakeModel(["Response"])

    with support_agent.override(model=fake_model.model):
        result = await support_agent.run("Test query")

    # FakeModel returns 30 total tokens
    assert result.usage().total_tokens <= 100, "Token usage exceeds limit"


@pytest.mark.asyncio
async def test_performance_across_multiple_queries():
    """Test consistent performance across multiple queries."""
    monitor = PerformanceMonitor(max_latency_ms=200, max_tokens=100)
    agent = create_test_agent(["Response"] * 10)

    queries = [f"Query {i}" for i in range(10)]

    for query in queries:
        await monitor.measure_query(agent, query)

    summary = monitor.get_summary()

    assert summary["success_rate"] == 1.0, "Not all queries succeeded"
    assert (
        summary["avg_latency_ms"] < monitor.max_latency_ms
    ), f"Average latency {summary['avg_latency_ms']:.1f}ms exceeds limit"


@pytest.mark.asyncio
async def test_concurrent_query_performance():
    """Test performance under concurrent load."""
    monitor = PerformanceMonitor(max_latency_ms=500)
    agent = create_test_agent(["Response"] * 20)

    # Measure concurrent queries
    tasks = [monitor.measure_query(agent, f"Query {i}") for i in range(20)]

    metrics = await asyncio.gather(*tasks)

    # All should complete successfully
    assert all(m.success for m in metrics), "Some queries failed"

    # Check latencies
    avg_latency = sum(m.latency_ms for m in metrics) / len(metrics)
    assert (
        avg_latency < monitor.max_latency_ms
    ), f"Average latency {avg_latency:.1f}ms exceeds limit"


@pytest.mark.asyncio
async def test_sla_compliance_reporting():
    """Test SLA compliance checking."""
    monitor = PerformanceMonitor(max_latency_ms=50, max_tokens=40)
    agent = create_test_agent("Response")

    # Run several queries
    for i in range(5):
        await monitor.measure_query(agent, f"Query {i}")

    # Get violations
    violations = monitor.get_violations()

    # Check if we can detect violations
    assert isinstance(violations, list)


@pytest.mark.asyncio
async def test_performance_regression():
    """Test for performance regressions."""
    # Baseline performance
    baseline_monitor = PerformanceMonitor()
    baseline_agent = create_test_agent("Fast response")

    baseline_metric = await baseline_monitor.measure_query(baseline_agent, "Test query")

    baseline_latency = baseline_metric.latency_ms

    # New version performance
    new_monitor = PerformanceMonitor()
    new_agent = create_test_agent("Fast response")

    new_metric = await new_monitor.measure_query(new_agent, "Test query")

    # New version shouldn't be more than 50% slower
    regression_threshold = baseline_latency * 1.5

    assert (
        new_metric.latency_ms < regression_threshold
    ), f"Performance regression detected: {new_metric.latency_ms:.1f}ms vs baseline {baseline_latency:.1f}ms"


@pytest.mark.slow
@pytest.mark.asyncio
async def test_sustained_load_performance():
    """Test performance under sustained load."""
    monitor = PerformanceMonitor(max_latency_ms=300)
    agent = create_test_agent(["Response"] * 100)

    # Run 100 queries sequentially (sustained load)
    for i in range(100):
        await monitor.measure_query(agent, f"Query {i}")

    summary = monitor.get_summary()

    # Performance should remain consistent
    assert summary["success_rate"] >= 0.99, "Too many failures under load"
    assert (
        summary["max_latency_ms"] < monitor.max_latency_ms * 2
    ), "Max latency too high under load"


@pytest.mark.asyncio
async def test_percentile_latencies():
    """Test latency percentiles."""
    monitor = PerformanceMonitor()
    agent = create_test_agent(["Response"] * 50)

    # Run queries
    for i in range(50):
        await monitor.measure_query(agent, f"Query {i}")

    latencies = sorted([m.latency_ms for m in monitor.metrics])

    # Calculate percentiles
    p50 = latencies[len(latencies) // 2]
    p95 = latencies[int(len(latencies) * 0.95)]
    p99 = latencies[int(len(latencies) * 0.99)]

    print(f"\nLatency Percentiles:")
    print(f"  P50: {p50:.1f}ms")
    print(f"  P95: {p95:.1f}ms")
    print(f"  P99: {p99:.1f}ms")

    # P95 should be reasonable
    assert p95 < monitor.max_latency_ms, "P95 latency exceeds limit"


if __name__ == "__main__":

    async def demo():
        print("Performance Testing Demo\n")
        print("=" * 60)

        monitor = PerformanceMonitor(max_latency_ms=200, max_tokens=100)
        agent = create_test_agent(["Response"] * 10)

        queries = [
            "What's the order status?",
            "Create a ticket",
            "Track package",
            "Return policy",
            "Help needed",
        ]

        print("\nRunning performance tests...")
        for query in queries:
            metric = await monitor.measure_query(agent, query)
            compliance = monitor.check_sla_compliance(metric)

            status = "✓" if compliance["overall_ok"] else "✗"
            print(
                f"{status} {query}: {metric.latency_ms:.1f}ms, {metric.tokens_used} tokens"
            )

        print("\n" + "=" * 60)
        summary = monitor.get_summary()
        print("\nSummary:")
        print(f"  Total queries: {summary['total_queries']}")
        print(f"  Success rate: {summary['success_rate']:.1%}")
        print(f"  Avg latency: {summary['avg_latency_ms']:.1f}ms")
        print(f"  Max latency: {summary['max_latency_ms']:.1f}ms")
        print(f"  Avg tokens: {summary['avg_tokens']:.0f}")
        print(f"  Total tokens: {summary['total_tokens']}")

        violations = monitor.get_violations()
        if violations:
            print(f"\nSLA Violations: {len(violations)}")
            for v in violations:
                print(f"  - {v['query']}: {v['latency_ms']:.1f}ms")
        else:
            print("\n✓ All queries within SLA")

    asyncio.run(demo())

    # Run pytest
    pytest.main([__file__, "-v"])
