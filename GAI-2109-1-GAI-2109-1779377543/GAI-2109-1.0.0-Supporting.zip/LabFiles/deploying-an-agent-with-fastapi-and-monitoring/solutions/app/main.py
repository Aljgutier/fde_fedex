"""
FastAPI Application Entry Point
Customer support agent API with authentication, rate limiting, and monitoring
"""

from fastapi import FastAPI, Request, HTTPException, Depends, status
from fastapi.responses import JSONResponse, StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
import logging
import os
import time
from datetime import datetime
from dotenv import load_dotenv

from app.models import (
    AgentRequest,
    AgentResponse,
    ErrorResponse,
    HealthResponse,
    MetricsResponse,
)
from app.agent import process_query, stream_query_response
from app.middleware import verify_api_key, rate_limit
from app.monitoring import metrics_collector, health_checker

import uuid


async def check_rate_limit(api_key: str = Depends(verify_api_key)) -> None:
    """Dependency that performs rate limiting using the authenticated API key."""
    allowed = await rate_limit(api_key)
    if not allowed:
        raise HTTPException(
            status_code=429,
            detail="Rate limit exceeded. Please try again later.",
        )

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

# Create FastAPI app
app = FastAPI(
    title="AI Agent API",
    description="Customer support agent with authentication and monitoring",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify allowed origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Request logging middleware
@app.middleware("http")
async def log_requests(request: Request, call_next):
    """
    Log all incoming requests and responses.

    Also tracks request latency for metrics.
    """
    start_time = time.time()

    # Log request
    logger.info(
        f"Request: {request.method} {request.url.path} " f"from {request.client.host}"
    )

    # Process request
    try:
        response = await call_next(request)
    except Exception as e:
        logger.error(f"Request failed: {e}", exc_info=True)
        metrics_collector.record_error()
        raise

    # Calculate latency
    latency_ms = (time.time() - start_time) * 1000

    # Log response
    logger.info(f"Response: {response.status_code} " f"(latency: {latency_ms:.2f}ms)")

    # Add latency header
    response.headers["X-Process-Time"] = f"{latency_ms:.2f}ms"

    return response


@app.get("/")
async def root():
    """Root endpoint with API information."""
    return {
        "name": "AI Agent API",
        "version": "1.0.0",
        "status": "operational",
        "endpoints": {
            "query": "/v1/query",
            "health": "/health",
            "metrics": "/metrics",
            "docs": "/docs",
        },
        "timestamp": datetime.now().isoformat(),
    }


@app.get("/health", response_model=HealthResponse, tags=["monitoring"])
async def health_check():
    """
    Health check endpoint.

    Verifies service is operational and all dependencies are available.
    """
    # YOUR CODE HERE
    # [SOLUTION]
    try:
        # Perform health check
        is_healthy = await health_checker.check()

        # Get uptime
        uptime = health_checker.get_uptime()

        # Return health status
        return HealthResponse(
            status="healthy" if is_healthy else "unhealthy",
            timestamp=datetime.now(),
            version="1.0.0",
            model_available=is_healthy,
            uptime_seconds=uptime,
        )

    except Exception as e:
        logger.error(f"Health check failed: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Health check failed",
        )
    # [/SOLUTION]


@app.get("/metrics", response_model=MetricsResponse, tags=["monitoring"])
async def get_metrics():
    """
    Get current usage metrics.

    Returns aggregated metrics including:
    - Request count
    - Token usage
    - Cost estimates
    - Latency statistics
    - Error rates
    """
    try:
        metrics = metrics_collector.get_detailed_metrics()

        return MetricsResponse(
            total_requests=metrics["total_requests"],
            total_tokens=metrics["total_tokens"],
            total_cost_usd=metrics["total_cost_usd"],
            avg_latency_ms=metrics["avg_latency_ms"],
            error_rate=metrics["error_rate"],
            uptime_seconds=metrics["uptime_seconds"],
        )

    except Exception as e:
        logger.error(f"Metrics collection failed: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Metrics collection failed",
        )


@app.post(
    "/v1/query",
    response_model=AgentResponse,
    responses={
        401: {"model": ErrorResponse},
        429: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    },
    tags=["agent"],
)
async def query_agent(
    request: AgentRequest,
    api_key: str = Depends(verify_api_key),
    rate_limit_check: None = Depends(check_rate_limit),
):
    """
    Process a query through the customer support agent.

    Requires authentication via Bearer token.
    Subject to rate limiting (10 requests per minute per API key).
    """
    # YOUR CODE HERE
    # [SOLUTION]
    start_time = time.time()
    success = False
    tokens_used = 0

    try:
        logger.info(f"Processing query for session: {request.session_id}")
        logger.debug(f"Query: {request.query[:100]}...")

        # Process query
        result = await process_query(
            query=request.query, session_id=request.session_id, context=request.context
        )

        # Extract token usage (if available in response)
        # This would come from the model response
        tokens_used = result.get("tokens_used", 0)

        success = True

        # Calculate latency
        latency_ms = (time.time() - start_time) * 1000

        # Record metrics
        metrics_collector.record_request(
            tokens=tokens_used, latency=latency_ms, success=success
        )

        # Return response
        return AgentResponse(
            request_id=f"req_{uuid.uuid4().hex[:12]}",
            response=result["response"],
            session_id=result.get("session_id"),
            metadata={
                "tokens_used": tokens_used,
                "latency_ms": round(latency_ms, 2),
                "model": result.get("model", "unknown"),
            },
        )

    except Exception as e:
        logger.error(f"Query processing failed: {e}", exc_info=True)

        # Calculate latency even for errors
        latency_ms = (time.time() - start_time) * 1000

        # Record failed request
        metrics_collector.record_request(
            tokens=tokens_used, latency=latency_ms, success=False
        )

        # Return error response
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to process query: {str(e)}",
        )
    # [/SOLUTION]


@app.post("/v1/query/stream", tags=["agent"])
async def stream_agent_response(
    request: AgentRequest,
    api_key: str = Depends(verify_api_key),
    rate_limit_check: None = Depends(check_rate_limit),
):
    """
    Stream agent responses using Server-Sent Events.

    This endpoint is part of Challenge 2.
    Implement streaming responses for better UX with long queries.
    """
    try:
        logger.info(f"Streaming query for session: {request.session_id}")

        # Create streaming generator
        async def generate():
            async for chunk in stream_query_response(
                query=request.query,
                session_id=request.session_id,
            ):
                yield f"data: {chunk}\n\n"

        return StreamingResponse(generate(), media_type="text/event-stream")

    except Exception as e:
        logger.error(f"Streaming query failed: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to stream response: {str(e)}",
        )


# Exception handlers
@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    """Handle HTTP exceptions with consistent error format."""
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": exc.detail,
            "status_code": exc.status_code,
            "timestamp": datetime.now().isoformat(),
        },
    )


@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    """Handle unexpected exceptions."""
    logger.error(f"Unexpected error: {exc}", exc_info=True)
    metrics_collector.record_error()

    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={
            "error": "Internal server error",
            "status_code": 500,
            "timestamp": datetime.now().isoformat(),
        },
    )


# Startup and shutdown events
@app.on_event("startup")
async def startup_event():
    """Initialize services on startup."""
    logger.info("Starting AI Agent API...")
    logger.info("Verifying model availability...")

    # Verify model is available
    is_healthy = await health_checker.check(force=True)
    if not is_healthy:
        logger.warning("Model health check failed at startup")
    else:
        logger.info("Model health check passed")

    logger.info("AI Agent API started successfully")


@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on shutdown."""
    logger.info("Shutting down AI Agent API...")
    logger.info(f"Final metrics: {metrics_collector.get_metrics()}")
    logger.info("AI Agent API shutdown complete")


if __name__ == "__main__":
    import uvicorn

    # Get port from environment or default to 8000
    port = int(os.getenv("PORT", 8000))

    # Run server
    uvicorn.run(
        "app.main:app", host="0.0.0.0", port=port, reload=True, log_level="info"
    )
