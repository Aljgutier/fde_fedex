"""
API Integration Tests
Test the deployed FastAPI application endpoints
"""

import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.middleware import API_KEYS
from app.monitoring import metrics_collector, health_checker

# Create test client
client = TestClient(app)

# Test API key
TEST_API_KEY = "test_key_123"


class TestHealthEndpoints:
    """Test health check and monitoring endpoints."""

    def test_root_endpoint(self):
        """Test root endpoint returns API information."""
        response = client.get("/")

        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "AI Agent API"
        assert "endpoints" in data
        assert "timestamp" in data

    def test_health_check(self):
        """Test health check endpoint.

        Asserts the fields actually defined on `HealthResponse` (status,
        timestamp, version, model_available, uptime_seconds). The pre-fix
        version asserted ``"checks" in data`` — `HealthResponse` has no
        such field, so the assertion failed unconditionally.
        """
        response = client.get("/health")

        assert response.status_code == 200
        data = response.json()
        assert "status" in data
        assert "timestamp" in data
        assert "version" in data
        assert "model_available" in data
        assert "uptime_seconds" in data

    def test_metrics_endpoint(self):
        """Test metrics endpoint returns usage data."""
        response = client.get("/metrics")

        assert response.status_code == 200
        data = response.json()
        assert "total_requests" in data
        assert "total_tokens" in data
        assert "total_cost_usd" in data
        assert "avg_latency_ms" in data
        assert "error_rate" in data
        assert "uptime_seconds" in data


class TestAuthentication:
    """Test API key authentication."""

    def test_missing_api_key(self):
        """Test request without API key is rejected.

        Asserts the actual middleware-emitted detail text. The pre-fix
        version asserted ``"Missing API key" in data["error"]``, but
        `verify_api_key` in `app/middleware.py` raises with
        ``detail="Missing Authorization header"``.
        """
        response = client.post(
            "/v1/query", json={"query": "Test query", "user_id": "test_user"}
        )

        assert response.status_code == 401
        data = response.json()
        assert "error" in data
        assert "Missing Authorization header" in data["error"]

    def test_invalid_api_key(self):
        """Test request with invalid API key is rejected."""
        response = client.post(
            "/v1/query",
            headers={"Authorization": "Bearer invalid_key"},
            json={"query": "Test query", "user_id": "test_user"},
        )

        assert response.status_code == 401
        data = response.json()
        assert "error" in data
        assert "Invalid API key" in data["error"]

    def test_valid_api_key(self):
        """Test request with valid API key is accepted."""
        response = client.post(
            "/v1/query",
            headers={"Authorization": f"Bearer {TEST_API_KEY}"},
            json={"query": "What is your return policy?", "user_id": "test_user"},
        )

        # Should succeed (200) or fail with server error (500)
        # but not authentication error (401)
        assert response.status_code != 401


class TestRateLimiting:
    """Test rate limiting enforcement."""

    def test_rate_limit_enforcement(self):
        """Test that rate limiting blocks excessive requests."""
        # Reset metrics for clean test
        metrics_collector.reset_metrics()

        # Make requests up to the limit (10 per minute)
        success_count = 0
        rate_limited = False

        for i in range(15):
            response = client.post(
                "/v1/query",
                headers={"Authorization": f"Bearer {TEST_API_KEY}"},
                json={"query": f"Test query {i}", "user_id": "test_user"},
            )

            if response.status_code == 200:
                success_count += 1
            elif response.status_code == 429:
                rate_limited = True
                data = response.json()
                assert "error" in data
                assert "Rate limit exceeded" in data["error"]

        # Should have some successful requests
        assert success_count > 0
        # Should eventually hit rate limit
        assert rate_limited, "Rate limiting should block excessive requests"


class TestQueryEndpoint:
    """Test agent query processing."""

    def test_successful_query(self):
        """Test successful query processing."""
        response = client.post(
            "/v1/query",
            headers={"Authorization": f"Bearer {TEST_API_KEY}"},
            json={
                "query": "What is your return policy?",
                "user_id": "test_user",
                "session_id": "test_session",
            },
        )

        # Check response structure. AgentResponse exposes top-level
        # request_id / response / session_id / metadata; tokens_used,
        # confidence, latency_ms, and model live INSIDE metadata. The
        # pre-fix version asserted top-level "confidence" / "tokens_used"
        # which are nested keys, so the shape check failed silently
        # (skipping the asserts) when the request returned 200.
        if response.status_code == 200:
            data = response.json()
            assert "request_id" in data
            assert "response" in data
            assert "metadata" in data
            assert isinstance(data["response"], str)
            assert len(data["response"]) > 0

    def test_query_validation(self):
        """Test request validation."""
        # Missing required field
        response = client.post(
            "/v1/query",
            headers={"Authorization": f"Bearer {TEST_API_KEY}"},
            json={
                "user_id": "test_user"
                # Missing 'query'
            },
        )

        assert response.status_code == 422  # Validation error

    def test_empty_query(self):
        """Test handling of empty query."""
        response = client.post(
            "/v1/query",
            headers={"Authorization": f"Bearer {TEST_API_KEY}"},
            json={"query": "", "user_id": "test_user"},
        )

        # Should fail validation
        assert response.status_code == 422

    def test_query_with_session(self):
        """Test query with session ID for context."""
        response = client.post(
            "/v1/query",
            headers={"Authorization": f"Bearer {TEST_API_KEY}"},
            json={
                "query": "What is your return policy?",
                "user_id": "test_user",
                "session_id": "test_session_123",
            },
        )

        # Should accept session_id
        assert response.status_code in [200, 500]  # Success or server error


class TestStreamingEndpoint:
    """Test streaming query endpoint (Challenge 2)."""

    def test_streaming_endpoint_exists(self):
        """Test streaming endpoint is available."""
        response = client.post(
            "/v1/query/stream",
            headers={"Authorization": f"Bearer {TEST_API_KEY}"},
            json={"query": "Tell me about shipping", "user_id": "test_user"},
        )

        # Should not return 404
        assert response.status_code != 404

    def test_streaming_authentication(self):
        """Test streaming requires authentication."""
        response = client.post(
            "/v1/query/stream", json={"query": "Test query", "user_id": "test_user"}
        )

        assert response.status_code == 401


class TestErrorHandling:
    """Test error handling and logging."""

    def test_404_error(self):
        """Test 404 for non-existent endpoint."""
        response = client.get("/nonexistent")

        assert response.status_code == 404

    def test_method_not_allowed(self):
        """Test 405 for wrong HTTP method."""
        response = client.get("/v1/query")  # Should be POST

        assert response.status_code == 405

    def test_error_response_format(self):
        """Test error responses have consistent format."""
        response = client.post(
            "/v1/query",
            json={
                "query": "test"
                # Missing user_id
            },
        )

        data = response.json()
        # Pydantic validation errors have 'detail' field
        assert "detail" in data or "error" in data


class TestMetricsTracking:
    """Test metrics collection and tracking."""

    def test_metrics_update_on_request(self):
        """Test that metrics are updated after requests."""
        # Get initial metrics
        initial_response = client.get("/metrics")
        initial_data = initial_response.json()
        initial_count = initial_data["total_requests"]

        # Make a query
        client.post(
            "/v1/query",
            headers={"Authorization": f"Bearer {TEST_API_KEY}"},
            json={"query": "Test for metrics", "user_id": "test_user"},
        )

        # Get updated metrics
        final_response = client.get("/metrics")
        final_data = final_response.json()
        final_count = final_data["total_requests"]

        # Metrics should have increased
        assert final_count > initial_count

    def test_latency_tracking(self):
        """Test that latency is tracked in response headers."""
        response = client.post(
            "/v1/query",
            headers={"Authorization": f"Bearer {TEST_API_KEY}"},
            json={"query": "Quick test", "user_id": "test_user"},
        )

        # Should have process time header
        assert "X-Process-Time" in response.headers
        process_time = response.headers["X-Process-Time"]
        assert "ms" in process_time


if __name__ == "__main__":
    # Run tests with pytest
    pytest.main([__file__, "-v"])
