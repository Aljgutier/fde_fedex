# FastAPI Agent Deployment - Solution Files

Complete reference implementation for deploying an AI agent with FastAPI, including authentication, rate limiting, monitoring, and Docker containerization.

## Project Structure

```
.
├── app/
│   ├── __init__.py          # Package initialization
│   ├── main.py              # FastAPI application entry point
│   ├── agent.py             # Agent processing logic
│   ├── models.py            # Pydantic models for API
│   ├── middleware.py        # Authentication and rate limiting
│   └── monitoring.py        # Metrics and health checks
├── tests/
│   ├── __init__.py
│   └── test_api.py          # API integration tests
├── Dockerfile               # Container build configuration
├── docker-compose.yml       # Service orchestration
├── .dockerignore            # Docker build exclusions
├── pyproject.toml           # UV dependencies
└── .env.example             # Environment template
```

## Quick Start

### 1. Setup Environment

```bash
# Copy environment template
cp .env.example .env

# Edit .env and add your OpenAI API key
# OPENAI_API_KEY=your-key-here
```

### 2. Install Dependencies

```bash
# Install with UV
uv sync

# Or with pip
pip install -r requirements.txt
```

### 3. Run Locally

```bash
# Start the server
uv run uvicorn app.main:app --reload

# Or directly with Python
python -m app.main
```

The API will be available at http://localhost:8000

## API Endpoints

### Query Agent

```bash
curl -X POST http://localhost:8000/v1/query \
  -H "Authorization: Bearer test_key_123" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "What is your return policy?",
    "user_id": "user_123"
  }'
```

### Health Check

```bash
curl http://localhost:8000/health
```

### Metrics

```bash
curl http://localhost:8000/metrics
```

### API Documentation

- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc

## Docker Deployment

### Build and Run

```bash
# Build image
docker build -t agent-api .

# Run container
docker run -p 8000:8000 --env-file .env agent-api
```

### Using Docker Compose

```bash
# Start API only
docker-compose up

# Start with Redis (for distributed rate limiting)
docker-compose --profile with-redis up

# Start with full monitoring stack
docker-compose --profile with-monitoring up

# Build and start
docker-compose up --build

# Run in background
docker-compose up -d
```

## Testing

### Run Tests

```bash
# Run all tests
uv run pytest tests/ -v

# Run with coverage
uv run pytest tests/ --cov=app --cov-report=html

# Run specific test class
uv run pytest tests/test_api.py::TestAuthentication -v
```

### Manual Testing

```bash
# Test with valid API key
curl -X POST http://localhost:8000/v1/query \
  -H "Authorization: Bearer test_key_123" \
  -H "Content-Type: application/json" \
  -d '{"query": "Hello", "user_id": "test"}'

# Test without API key (should fail with 401)
curl -X POST http://localhost:8000/v1/query \
  -H "Content-Type: application/json" \
  -d '{"query": "Hello", "user_id": "test"}'

# Test rate limiting (run 15 times quickly)
for i in {1..15}; do
  curl -X POST http://localhost:8000/v1/query \
    -H "Authorization: Bearer test_key_123" \
    -H "Content-Type: application/json" \
    -d "{\"query\": \"Test $i\", \"user_id\": \"test\"}"
  echo ""
done
```

## API Keys

The solution includes three test API keys (in production, use a secure key store):

- `test_key_123` - For testing
- `prod_key_456` - Production simulation
- `demo_key_789` - Demo purposes

## Features

### Authentication

- Bearer token authentication
- API key validation
- Secure error messages

### Rate Limiting

- 10 requests per minute per API key
- Token bucket algorithm
- In-memory storage (Redis ready)
- Rate limit headers in responses

### Monitoring

- Health check endpoint with dependency validation
- Metrics collection (requests, tokens, latency, errors)
- Request/response logging
- Cost estimation

### Error Handling

- Consistent error response format
- Proper HTTP status codes
- Detailed logging
- Exception tracking

### Docker Support

- Multi-stage build for smaller images
- Non-root user for security
- Health checks
- Environment-based configuration

## Challenge Solutions

### Challenge 1: Distributed Rate Limiting

The solution includes Redis support in `docker-compose.yml`. To implement:

1. Start with Redis profile:

   ```bash
   docker-compose --profile with-redis up
   ```

2. Update `middleware.py` to use Redis instead of in-memory dict

3. Example Redis implementation:
   ```python
   import redis
   r = redis.Redis(host='redis', port=6379)
   ```

### Challenge 2: Streaming Responses

The `/v1/query/stream` endpoint is implemented with SSE support:

```python
async def stream_query_response(query, user_id, session_id):
    # Implement streaming logic here
    async for chunk in agent.run_stream(query):
        yield chunk
```

Test streaming:

```bash
curl -X POST http://localhost:8000/v1/query/stream \
  -H "Authorization: Bearer test_key_123" \
  -H "Content-Type: application/json" \
  -d '{"query": "Tell me a story", "user_id": "test"}' \
  --no-buffer
```

## Production Considerations

### Security

- [ ] Use environment variables for API keys
- [ ] Implement proper key rotation
- [ ] Add HTTPS/TLS
- [ ] Use secrets management (AWS Secrets Manager, HashiCorp Vault)
- [ ] Add input validation and sanitization
- [ ] Implement request signing

### Scalability

- [ ] Use Redis for distributed rate limiting
- [ ] Add database for persistent storage
- [ ] Implement caching layer
- [ ] Use load balancer
- [ ] Add horizontal pod autoscaling

### Monitoring

- [ ] Send metrics to Prometheus
- [ ] Set up Grafana dashboards
- [ ] Configure alerts
- [ ] Add distributed tracing (OpenTelemetry)
- [ ] Log aggregation (ELK stack)

### Reliability

- [ ] Add circuit breakers
- [ ] Implement retry logic with exponential backoff
- [ ] Set up dead letter queues
- [ ] Add graceful shutdown
- [ ] Implement backup/restore procedures

## Environment Variables

Required:

- `OPENAI_API_KEY` - Your OpenAI API key

Optional:

- `PORT` - Server port (default: 8000)
- `LOG_LEVEL` - Logging level (default: INFO)
- `RATE_LIMIT_REQUESTS` - Max requests per minute (default: 10)
- `RATE_LIMIT_WINDOW` - Time window in seconds (default: 60)

## Troubleshooting

### Container health check fails

- Check OpenAI API key is set correctly
- Verify network connectivity
- Check application logs: `docker logs agent-api`

### Rate limiting not working

- Verify API key is being sent
- Check rate limit configuration
- Review middleware logs

### Tests failing

- Ensure dependencies installed: `uv sync`
- Check OpenAI API key in .env
- Reset metrics before testing: `metrics_collector.reset_metrics()`

## Additional Resources

- [FastAPI Documentation](https://fastapi.tiangolo.com/)
- [Pydantic AI Documentation](https://ai.pydantic.dev/)
- [Docker Documentation](https://docs.docker.com/)
- [UV Package Manager](https://github.com/astral-sh/uv)

## License

Educational use only - Part of GAI-2109 course materials.
