"""
Agent Logic
AI agent implementation for customer support
"""

from pydantic_ai import Agent
from dotenv import load_dotenv
import os
from typing import Optional

load_dotenv()

# Verify API key is loaded
api_key = os.getenv("OPENAI_API_KEY")
if not api_key:
    raise ValueError(
        "OPENAI_API_KEY not found in environment variables. "
        "Make sure .env file exists."
    )

# Get model from environment variable
model = os.getenv("AI_MODEL", "openai:gpt-5.4-mini")

# Create customer support agent
support_agent = Agent(
    model,
    system_prompt="""You are a helpful and professional customer support agent.
    
    Your role:
    - Answer customer questions clearly and accurately
    - Maintain a friendly, professional tone
    - Provide helpful solutions to customer problems
    - Ask clarifying questions when needed
    - Be concise but thorough in your responses
    
    Always prioritize customer satisfaction and clear communication.""",
)


async def process_query(
    query: str, session_id: Optional[str] = None, context: Optional[dict] = None
) -> dict:
    """
    Process customer query with the agent.

    Args:
        query: User's question or request
        session_id: Optional session ID for conversation continuity
        context: Optional additional context for the query

    Returns:
        Dictionary containing:
        - response: Agent's response text
        - tokens_used: Number of tokens consumed
        - model: Model used for the response

    Raises:
        Exception: If agent processing fails
    """
    try:
        # In a real implementation, you would:
        # 1. Retrieve conversation history for session_id
        # 2. Include context in the query
        # 3. Store the result for future session continuity

        # Process query
        result = await support_agent.run(query)

        # Get usage information
        usage = result.usage()

        return {
            "response": result.output,
            "tokens_used": usage.total_tokens if usage else 0,
            "model": model,
            "session_id": session_id,
        }

    except Exception as e:
        # Log error and re-raise
        import logging

        logger = logging.getLogger(__name__)
        logger.error(
            f"Agent processing failed for query: {query[:100]}...", exc_info=True
        )
        raise


async def stream_query_response(query: str, session_id: Optional[str] = None):
    """
    Stream agent response for real-time output.

    This is a placeholder for Challenge 2 (streaming responses).
    In a real implementation, this would yield tokens as they're generated.

    Args:
        query: User's question or request
        session_id: Optional session ID

    Yields:
        Token chunks as they're generated
    """
    # For now, just yield the full response as a single chunk
    # Challenge 2 would implement actual streaming
    result = await process_query(query, session_id)
    yield result["response"]


async def validate_agent_health() -> bool:
    """
    Validate that the agent is operational.

    Returns:
        True if agent can process queries, False otherwise
    """
    try:
        # Simple health check - try processing a basic query
        result = await support_agent.run("health check")
        return bool(result.output)
    except Exception as e:
        import logging

        logger = logging.getLogger(__name__)
        logger.error(f"Agent health check failed: {e}")
        return False
