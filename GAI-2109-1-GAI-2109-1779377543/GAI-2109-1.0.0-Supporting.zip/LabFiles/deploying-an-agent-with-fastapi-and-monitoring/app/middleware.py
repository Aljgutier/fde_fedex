"""
Middleware Components
Authentication, rate limiting, and request processing middleware
"""

from fastapi import Header, HTTPException
from typing import Dict
import time
import logging

logger = logging.getLogger(__name__)

# Simple in-memory rate limiter
# In production, use Redis with sliding window algorithm
rate_limit_store: Dict[str, list] = {}

# API key store
# In production, store in database with hashed keys
API_KEYS = {
    "test_key_123": {"name": "Test User", "tier": "free"},
    "prod_key_456": {"name": "Production User", "tier": "premium"},
    "demo_key_789": {"name": "Demo User", "tier": "free"},
}


async def verify_api_key(authorization: str = Header(None)) -> str:
    """
    Verify API key from Authorization header.

    Args:
        authorization: Authorization header value (Bearer token)

    Returns:
        Validated API key

    Raises:
        HTTPException: If API key is missing or invalid
    """
    if not authorization:
        raise HTTPException(
            status_code=401,
            detail="Missing Authorization header",
            headers={"WWW-Authenticate": "Bearer"},
        )

    if not authorization.startswith("Bearer "):
        raise HTTPException(
            status_code=401,
            detail="Invalid Authorization format. Use 'Bearer <api_key>'",
            headers={"WWW-Authenticate": "Bearer"},
        )

    api_key = authorization.replace("Bearer ", "")

    if api_key not in API_KEYS:
        logger.warning(f"Invalid API key attempt: {api_key[:8]}...")
        raise HTTPException(
            status_code=401,
            detail="Invalid API key",
            headers={"WWW-Authenticate": "Bearer"},
        )

    logger.debug(f"Authenticated: {API_KEYS[api_key]['name']}")

    return api_key


async def get_api_key_info(api_key: str) -> dict:
    """
    Get information about an API key.

    Args:
        api_key: The API key to look up

    Returns:
        Dictionary with key information
    """
    return API_KEYS.get(api_key, {})


async def rate_limit(
    api_key: str, max_requests: int = 10, window_seconds: int = 60
) -> bool:
    """
    Simple token bucket rate limiter.

    In production, use Redis with sliding window algorithm like:
    - ZREMRANGEBYSCORE to clean old entries
    - ZADD to add new timestamp
    - ZCARD to count entries in window

    Args:
        api_key: API key to rate limit
        max_requests: Maximum requests allowed in window
        window_seconds: Time window in seconds

    Returns:
        True if request is allowed, False if limit exceeded
    """
    now = time.time()

    # Initialize if new key
    if api_key not in rate_limit_store:
        rate_limit_store[api_key] = []

    # Remove timestamps outside the window
    rate_limit_store[api_key] = [
        timestamp
        for timestamp in rate_limit_store[api_key]
        if now - timestamp < window_seconds
    ]

    # Check if under limit
    current_count = len(rate_limit_store[api_key])

    if current_count >= max_requests:
        logger.warning(
            f"Rate limit exceeded for API key: {api_key[:8]}... "
            f"({current_count}/{max_requests} requests in {window_seconds}s)"
        )
        return False

    # Record this request
    rate_limit_store[api_key].append(now)

    logger.debug(
        f"Rate limit check passed: {api_key[:8]}... "
        f"({current_count + 1}/{max_requests})"
    )

    return True


def get_rate_limit_info(api_key: str, window_seconds: int = 60) -> dict:
    """
    Get current rate limit status for an API key.

    Args:
        api_key: API key to check
        window_seconds: Time window

    Returns:
        Dictionary with rate limit information
    """
    now = time.time()

    if api_key not in rate_limit_store:
        return {
            "requests_in_window": 0,
            "window_seconds": window_seconds,
            "reset_in_seconds": window_seconds,
        }

    # Clean old entries
    valid_timestamps = [
        ts for ts in rate_limit_store[api_key] if now - ts < window_seconds
    ]

    oldest_timestamp = min(valid_timestamps) if valid_timestamps else now
    reset_in = window_seconds - (now - oldest_timestamp)

    return {
        "requests_in_window": len(valid_timestamps),
        "window_seconds": window_seconds,
        "reset_in_seconds": max(0, reset_in),
    }


class RateLimitError(Exception):
    """Custom exception for rate limit violations."""

    def __init__(self, retry_after: float):
        self.retry_after = retry_after
        super().__init__(f"Rate limit exceeded. Retry after {retry_after:.0f}s")
