"""
Monitoring and Metrics
Health checks and usage metrics collection
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import List
import asyncio
import logging
from app.agent import validate_agent_health

logger = logging.getLogger(__name__)


@dataclass
class MetricsCollector:
    """
    Collect and aggregate usage metrics.

    In production, use Prometheus, StatsD, or CloudWatch metrics.
    """

    total_requests: int = 0
    total_tokens: int = 0
    total_errors: int = 0
    latencies: List[float] = field(default_factory=list)
    start_time: datetime = field(default_factory=datetime.now)

    # Token cost estimation (verify with your provider)
    COST_PER_1K_TOKENS: float = 0.003  # $0.003 per 1K tokens for gpt-5.4-mini

    def record_request(self, tokens: int, latency: float, success: bool = True):
        """
        Record a completed request.

        Args:
            tokens: Number of tokens used
            latency: Request latency in milliseconds
            success: Whether request succeeded
        """
        self.total_requests += 1
        self.total_tokens += tokens
        self.latencies.append(latency)

        if not success:
            self.total_errors += 1

        logger.debug(
            f"Recorded request: tokens={tokens}, latency={latency:.2f}ms, "
            f"success={success}"
        )

    def record_error(self):
        """Record an error without request details."""
        self.total_errors += 1
        logger.debug("Recorded error")

    def get_metrics(self) -> dict:
        """
        Get current metrics summary.

        Returns:
            Dictionary with aggregated metrics
        """
        # Calculate average latency
        avg_latency = sum(self.latencies) / len(self.latencies) if self.latencies else 0

        # Calculate error rate
        error_rate = (
            self.total_errors / self.total_requests if self.total_requests > 0 else 0
        )

        # Calculate estimated cost
        total_cost = (self.total_tokens / 1000) * self.COST_PER_1K_TOKENS

        # Calculate uptime
        uptime = (datetime.now() - self.start_time).total_seconds()

        return {
            "total_requests": self.total_requests,
            "total_tokens": self.total_tokens,
            "total_cost_usd": round(total_cost, 6),
            "avg_latency_ms": round(avg_latency, 2),
            "error_rate": round(error_rate, 4),
            "uptime_seconds": round(uptime, 2),
        }

    def get_detailed_metrics(self) -> dict:
        """
        Get detailed metrics including percentiles.

        Returns:
            Extended metrics dictionary
        """
        metrics = self.get_metrics()

        # Calculate latency percentiles
        if self.latencies:
            sorted_latencies = sorted(self.latencies)
            n = len(sorted_latencies)

            metrics["latency_p50"] = round(sorted_latencies[int(n * 0.5)], 2)
            metrics["latency_p95"] = round(sorted_latencies[int(n * 0.95)], 2)
            metrics["latency_p99"] = round(sorted_latencies[int(n * 0.99)], 2)
            metrics["latency_min"] = round(min(sorted_latencies), 2)
            metrics["latency_max"] = round(max(sorted_latencies), 2)

        # Add request rate
        uptime = (datetime.now() - self.start_time).total_seconds()
        if uptime > 0:
            metrics["requests_per_second"] = round(self.total_requests / uptime, 4)

        return metrics

    def reset_metrics(self):
        """Reset all metrics (useful for testing)."""
        self.total_requests = 0
        self.total_tokens = 0
        self.total_errors = 0
        self.latencies = []
        self.start_time = datetime.now()
        logger.info("Metrics reset")


class HealthChecker:
    """
    Health check logic for service readiness.

    In production, check:
    - Database connectivity
    - Model API availability
    - Cache availability
    - Dependency services
    """

    def __init__(self):
        self.last_check_time: datetime = None
        self.last_check_result: bool = None
        self.cache_duration: int = 30  # Cache health check for 30 seconds

    async def check(self, force: bool = False) -> bool:
        """
        Perform health check.

        Args:
            force: Force check even if cached result is available

        Returns:
            True if service is healthy, False otherwise
        """
        # Use cached result if recent
        if not force and self.last_check_result is not None:
            if self.last_check_time:
                age = (datetime.now() - self.last_check_time).total_seconds()
                if age < self.cache_duration:
                    logger.debug(
                        f"Using cached health check result: {self.last_check_result}"
                    )
                    return self.last_check_result

        try:
            # Check model availability
            model_available = await validate_agent_health()

            if not model_available:
                logger.warning("Health check failed: Model not available")
                self.last_check_result = False
                self.last_check_time = datetime.now()
                return False

            # All checks passed
            self.last_check_result = True
            self.last_check_time = datetime.now()
            logger.debug("Health check passed")
            return True

        except Exception as e:
            logger.error(f"Health check failed with exception: {e}", exc_info=True)
            self.last_check_result = False
            self.last_check_time = datetime.now()
            return False

    async def detailed_check(self) -> dict:
        """
        Perform detailed health check with component status.

        Returns:
            Dictionary with detailed health information
        """
        checks = {}

        # Check model
        try:
            checks["model"] = await validate_agent_health()
        except Exception as e:
            logger.error(f"Model health check failed: {e}")
            checks["model"] = False

        # Additional checks would go here
        # For example: database, cache, external APIs

        overall_healthy = all(checks.values())

        return {
            "healthy": overall_healthy,
            "checks": checks,
            "timestamp": datetime.now(),
        }

    def get_uptime(self) -> float:
        """
        Get service uptime in seconds.

        Returns:
            Uptime in seconds
        """
        # In production, track actual start time
        # For now, use metrics collector's start time
        return (datetime.now() - metrics_collector.start_time).total_seconds()


# Global instances
metrics_collector = MetricsCollector()
health_checker = HealthChecker()
