"""
API Models and Schemas
Pydantic models for request/response validation
"""

from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime


class AgentRequest(BaseModel):
    """API request model for agent queries."""

    query: str = Field(
        ...,
        min_length=1,
        max_length=1000,
        description="User query for the agent",
        examples=["What are your support hours?"],
    )
    session_id: Optional[str] = Field(
        None,
        description="Session ID for conversation continuity",
        examples=["session_abc123"],
    )
    context: Optional[dict] = Field(
        None, description="Additional context for the query"
    )

    model_config = {
        "json_schema_extra": {
            "examples": [
                {
                    "query": "How do I reset my password?",
                    "session_id": "session_123",
                    "context": {"user_id": "user_456"},
                }
            ]
        }
    }


class AgentResponse(BaseModel):
    """API response model for agent queries."""

    request_id: str = Field(..., description="Unique identifier for this request")
    response: str = Field(..., description="Agent's response to the query")
    session_id: Optional[str] = Field(
        None, description="Session ID if provided in request"
    )
    metadata: dict = Field(
        default_factory=dict, description="Response metadata (tokens, latency, model)"
    )

    model_config = {
        "json_schema_extra": {
            "examples": [
                {
                    "request_id": "req_12345",
                    "response": "Your order is being processed and will ship within 2 business days.",
                    "session_id": "session_abc",
                    "metadata": {
                        "tokens_used": 150,
                        "latency_ms": 850,
                        "model": "gpt-5.4-mini",
                    },
                }
            ]
        }
    }


class ErrorResponse(BaseModel):
    """Error response model."""

    error: str = Field(..., description="Error type or category")
    detail: Optional[str] = Field(None, description="Detailed error message")
    request_id: Optional[str] = Field(None, description="Request ID if available")

    model_config = {
        "json_schema_extra": {
            "examples": [
                {
                    "error": "validation_error",
                    "detail": "Query must be between 1 and 1000 characters",
                    "request_id": "req_98765",
                }
            ]
        }
    }


class HealthResponse(BaseModel):
    """Health check response."""

    status: str = Field(
        ..., description="Service health status", examples=["healthy", "unhealthy"]
    )
    timestamp: datetime = Field(..., description="Health check timestamp")
    version: str = Field(..., description="API version")
    model_available: bool = Field(..., description="Whether the AI model is accessible")
    uptime_seconds: Optional[float] = Field(
        None, description="Service uptime in seconds"
    )

    model_config = {
        "json_schema_extra": {
            "examples": [
                {
                    "status": "healthy",
                    "timestamp": "2026-04-10T14:30:00Z",
                    "version": "1.0.0",
                    "model_available": True,
                    "uptime_seconds": 3600.5,
                }
            ]
        }
    }


class MetricsResponse(BaseModel):
    """Usage metrics response."""

    total_requests: int = Field(
        ..., description="Total number of requests processed", ge=0
    )
    total_tokens: int = Field(..., description="Total tokens consumed", ge=0)
    total_cost_usd: float = Field(..., description="Estimated total cost in USD", ge=0)
    avg_latency_ms: float = Field(
        ..., description="Average request latency in milliseconds", ge=0
    )
    error_rate: float = Field(..., description="Error rate (0.0 to 1.0)", ge=0, le=1)
    uptime_seconds: float = Field(..., description="Service uptime in seconds", ge=0)

    model_config = {
        "json_schema_extra": {
            "examples": [
                {
                    "total_requests": 1250,
                    "total_tokens": 187500,
                    "total_cost_usd": 0.5625,
                    "avg_latency_ms": 742.35,
                    "error_rate": 0.0024,
                    "uptime_seconds": 86400.0,
                }
            ]
        }
    }
