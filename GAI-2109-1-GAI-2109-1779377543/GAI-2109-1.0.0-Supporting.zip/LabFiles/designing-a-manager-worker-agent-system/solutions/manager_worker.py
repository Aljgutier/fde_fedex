"""
Manager-Worker Agent System

Hierarchical multi-agent architecture:
- Manager agent decomposes tasks
- Worker agents execute subtasks
- Manager aggregates results
- Task queue management

Run: python manager_worker.py
"""

import asyncio
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pydantic_ai import Agent
import os
from dotenv import load_dotenv

load_dotenv()


class TaskStatus(Enum):
    """Status of a task."""

    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class Task:
    """A task to be executed."""

    id: str
    description: str
    assigned_worker: Optional[str] = None
    status: TaskStatus = TaskStatus.PENDING
    result: Optional[str] = None
    error: Optional[str] = None
    created_at: datetime = field(default_factory=datetime.now)
    completed_at: Optional[datetime] = None


class WorkerAgent:
    """Worker agent that executes tasks."""

    def __init__(self, name: str, specialty: str, model: Optional[str] = None):
        self.name = name
        self.specialty = specialty
        # Resolve model: explicit arg > AI_MODEL env > openai default.
        # Accept either a bare model name or a fully provider-prefixed
        # identifier; bare names get the openai prefix for backward compat.
        resolved = model or os.getenv("AI_MODEL", "openai:gpt-5.4-mini")
        if ":" not in resolved:
            resolved = f"openai:{resolved}"
        self.agent = Agent(
            resolved,
            system_prompt=f"""You are a specialist in {specialty}.
            Execute tasks thoroughly and provide detailed results.""",
        )
        self.tasks_completed = 0

    async def execute_task(self, task: Task) -> str:
        """Execute a task."""
        print(f"  [{self.name}] Executing: {task.description}")

        try:
            result = await self.agent.run(task.description)
            self.tasks_completed += 1
            return result.output
        except Exception as e:
            raise RuntimeError(f"Task execution failed: {e}")


class ManagerAgent:
    """Manager agent that orchestrates workers."""

    def __init__(self, model: Optional[str] = None):
        # Same env-var-aware model resolution as WorkerAgent.
        resolved = model or os.getenv("AI_MODEL", "openai:gpt-5.4-mini")
        if ":" not in resolved:
            resolved = f"openai:{resolved}"
        self.agent = Agent(
            resolved,
            system_prompt="""You are a project manager.
            Break down complex tasks into clear, actionable subtasks.
            Return subtasks as a numbered list, one per line.""",
        )
        self.workers: List[WorkerAgent] = []
        self.task_queue: List[Task] = []
        self.completed_tasks: List[Task] = []

    def register_worker(self, worker: WorkerAgent):
        """Register a worker agent."""
        self.workers.append(worker)
        print(f"✓ Registered worker: {worker.name} (specialty: {worker.specialty})")

    async def decompose_task(self, complex_task: str) -> List[str]:
        """Break complex task into subtasks. (Provided)"""
        print(f"\n{'─'*60}")
        print(f"Manager: Decomposing task")
        print(f"{'─'*60}")
        print(f"Task: {complex_task}\n")

        prompt = f"""Break this complex task into 3-5 clear, actionable subtasks:

Task: {complex_task}

Return only the subtasks, numbered, one per line."""

        result = await self.agent.run(prompt)

        # Parse subtasks
        subtasks = []
        for line in result.output.split("\n"):
            line = line.strip()
            if line and (line[0].isdigit() or line.startswith("-")):
                # Remove numbering
                task = line.lstrip("0123456789.-) ").strip()
                if task:
                    subtasks.append(task)

        print(f"Decomposed into {len(subtasks)} subtasks:")
        for i, subtask in enumerate(subtasks, 1):
            print(f"  {i}. {subtask}")
        print()

        return subtasks

    def assign_worker(self, task: Task) -> WorkerAgent:
        """Assign task to a worker."""
        if not self.workers:
            raise ValueError("No workers available")

        # Simple round-robin assignment
        worker = min(self.workers, key=lambda w: w.tasks_completed)
        task.assigned_worker = worker.name
        return worker

    async def execute_complex_task(
        self, complex_task: str, parallel: bool = True
    ) -> Dict[str, Any]:
        """Execute a complex task using workers."""
        # YOUR CODE HERE
        # [SOLUTION]
        start_time = datetime.now()

        # Step 1: Decompose
        subtasks_descriptions = await self.decompose_task(complex_task)

        # Create Task objects
        tasks = [
            Task(id=f"task_{i}", description=desc)
            for i, desc in enumerate(subtasks_descriptions, 1)
        ]

        # Step 2: Execute subtasks
        print(f"{'─'*60}")
        print(
            f"Executing {len(tasks)} subtasks ({'parallel' if parallel else 'sequential'})"
        )
        print(f"{'─'*60}\n")

        if parallel:
            results = await self._execute_parallel(tasks)
        else:
            results = await self._execute_sequential(tasks)

        # Step 3: Aggregate results
        print(f"\n{'─'*60}")
        print(f"Manager: Aggregating results")
        print(f"{'─'*60}\n")

        aggregated = await self._aggregate_results(complex_task, results)

        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()

        return {
            "original_task": complex_task,
            "subtasks": len(tasks),
            "results": results,
            "aggregated_result": aggregated,
            "duration_seconds": duration,
            "execution_mode": "parallel" if parallel else "sequential",
        }
        # [/SOLUTION]

    async def _execute_parallel(self, tasks: List[Task]) -> List[Dict[str, Any]]:
        """Execute tasks in parallel.

        Pre-assigns workers round-robin BEFORE wrapping the coroutines.
        If we let each `execute_one(task)` call `assign_worker(task)`
        itself, `asyncio.gather` schedules all coroutines effectively
        simultaneously, every assignment sees `tasks_completed == 0`,
        and `min(...)` consistently returns `workers[0]` — so every task
        ends up on the first worker (e.g. a 4/0/0 split for three
        workers). Pre-assignment fixes the load-balance.
        """

        # Pre-assign each task to a worker round-robin.
        for i, task in enumerate(tasks):
            worker = self.workers[i % len(self.workers)]
            task.assigned_worker = worker.name

        async def execute_one(task):
            # Look up the pre-assigned worker rather than calling
            # assign_worker(), which would re-run the broken min() logic.
            worker = next(w for w in self.workers if w.name == task.assigned_worker)
            task.status = TaskStatus.IN_PROGRESS

            try:
                result = await worker.execute_task(task)
                task.result = result
                task.status = TaskStatus.COMPLETED
                task.completed_at = datetime.now()
                self.completed_tasks.append(task)

                return {
                    "task_id": task.id,
                    "description": task.description,
                    "worker": worker.name,
                    "result": result,
                    "status": "completed",
                }
            except Exception as e:
                task.status = TaskStatus.FAILED
                task.error = str(e)
                return {
                    "task_id": task.id,
                    "description": task.description,
                    "worker": worker.name,
                    "error": str(e),
                    "status": "failed",
                }

        # YOUR CODE HERE
        # [SOLUTION]
        return await asyncio.gather(*[execute_one(task) for task in tasks])
        # [/SOLUTION]

    async def _execute_sequential(self, tasks: List[Task]) -> List[Dict[str, Any]]:
        """Execute tasks sequentially."""
        results = []

        for task in tasks:
            worker = self.assign_worker(task)
            task.status = TaskStatus.IN_PROGRESS

            try:
                result = await worker.execute_task(task)
                task.result = result
                task.status = TaskStatus.COMPLETED
                task.completed_at = datetime.now()
                self.completed_tasks.append(task)

                results.append(
                    {
                        "task_id": task.id,
                        "description": task.description,
                        "worker": worker.name,
                        "result": result,
                        "status": "completed",
                    }
                )
            except Exception as e:
                task.status = TaskStatus.FAILED
                task.error = str(e)
                results.append(
                    {
                        "task_id": task.id,
                        "description": task.description,
                        "worker": worker.name,
                        "error": str(e),
                        "status": "failed",
                    }
                )

        return results

    async def _aggregate_results(
        self, original_task: str, results: List[Dict[str, Any]]
    ) -> str:
        """Aggregate subtask results into final answer. (Provided)"""
        # Compile results
        results_text = "\n\n".join(
            [
                f"Subtask: {r['description']}\nResult: {r['result']}"
                for r in results
                if r["status"] == "completed"
            ]
        )

        prompt = f"""Aggregate these subtask results into a cohesive final answer:

Original Task: {original_task}

Subtask Results:
{results_text}

Provide a comprehensive final answer."""

        result = await self.agent.run(prompt)
        return result.output


# Example usage
async def main():
    """Demonstrate manager-worker system."""
    # YOUR CODE HERE
    # [SOLUTION]
    print("\n" + "=" * 60)
    print("  MANAGER-WORKER AGENT SYSTEM")
    print("=" * 60 + "\n")

    # Create manager
    manager = ManagerAgent()

    # Create workers
    workers = [
        WorkerAgent("ResearchWorker", "research and information gathering"),
        WorkerAgent("AnalysisWorker", "data analysis and insights"),
        WorkerAgent("WritingWorker", "content creation and writing"),
    ]

    for worker in workers:
        manager.register_worker(worker)

    # Execute complex task
    complex_task = """Create a comprehensive report on the impact of remote work on productivity. 
    Include research findings, analysis of trends, and practical recommendations."""

    print(f"\n{'='*60}")
    print(f"  Starting Complex Task")
    print(f"{'='*60}\n")

    result = await manager.execute_complex_task(complex_task, parallel=True)

    # Display results
    print(f"\n{'='*60}")
    print(f"  FINAL RESULTS")
    print(f"{'='*60}\n")

    print(f"Original Task: {result['original_task']}")
    print(f"Subtasks Executed: {result['subtasks']}")
    print(f"Execution Mode: {result['execution_mode']}")
    print(f"Duration: {result['duration_seconds']:.1f}s")

    print(f"\n{'─'*60}")
    print(f"Final Aggregated Result:")
    # [/SOLUTION]
    print(f"{'─'*60}")
    print(result["aggregated_result"])

    print(f"\n{'─'*60}")
    print(f"Worker Statistics:")
    print(f"{'─'*60}")
    for worker in manager.workers:
        print(f"{worker.name}: {worker.tasks_completed} tasks completed")

    print(f"\n{'='*60}\n")


if __name__ == "__main__":
    asyncio.run(main())
