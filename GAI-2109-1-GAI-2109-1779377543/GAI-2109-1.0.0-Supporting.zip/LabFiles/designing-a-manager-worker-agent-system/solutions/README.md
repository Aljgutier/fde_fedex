# Manager-Worker Agent System - Solution

Hierarchical multi-agent system with manager orchestrating workers.

## Features

- Task decomposition by manager
- Parallel/sequential worker execution
- Result aggregation
- Load balancing

## Quick Start

```bash
cp .env.example .env
uv sync
uv run python manager_worker.py
```

Educational use - GAI-2109.
