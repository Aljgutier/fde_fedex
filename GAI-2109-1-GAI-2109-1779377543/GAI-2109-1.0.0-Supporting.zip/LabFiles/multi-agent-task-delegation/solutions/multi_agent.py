"""
Multi-Agent Task Delegation

Coordinate multiple specialist agents for complex tasks:
- Task routing to appropriate agents
- Parallel execution
- Result aggregation
- Agent selection strategies

Run: python multi_agent.py
"""

import asyncio
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from enum import Enum
from pydantic_ai import Agent
import os
from dotenv import load_dotenv

load_dotenv()


class AgentCapability(Enum):
    """Agent capabilities."""

    RESEARCH = "research"
    WRITING = "writing"
    ANALYSIS = "analysis"
    CODING = "coding"
    TRANSLATION = "translation"
    SUMMARIZATION = "summarization"


@dataclass
class AgentSpec:
    """Specification for a specialist agent."""

    name: str
    capabilities: List[AgentCapability]
    agent: Agent
    cost_multiplier: float = 1.0  # Relative cost
    performance_score: float = 1.0  # Historical performance


class TaskRouter:
    """Routes tasks to appropriate agents."""

    def __init__(self):
        self.agents: Dict[str, AgentSpec] = {}

    def register_agent(self, spec: AgentSpec):
        """Register a specialist agent."""
        self.agents[spec.name] = spec

    def find_agent(
        self, capability: AgentCapability, prefer_quality: bool = True
    ) -> Optional[AgentSpec]:
        """Find best agent for capability."""
        # YOUR CODE HERE
        # [SOLUTION]
        candidates = [
            spec for spec in self.agents.values() if capability in spec.capabilities
        ]

        if not candidates:
            return None

        if prefer_quality:
            # Choose highest performance
            return max(candidates, key=lambda x: x.performance_score)
        else:
            # Choose lowest cost
            return min(candidates, key=lambda x: x.cost_multiplier)
        # [/SOLUTION]

    def find_agents_for_task(
        self, required_capabilities: List[AgentCapability]
    ) -> Dict[AgentCapability, AgentSpec]:
        """Find agents for each required capability."""
        assignments = {}

        for capability in required_capabilities:
            agent = self.find_agent(capability)
            if agent:
                assignments[capability] = agent

        return assignments


class MultiAgentCoordinator:
    """Coordinates multiple agents working on related tasks."""

    def __init__(self, router: TaskRouter):
        self.router = router

    async def delegate_task(
        self, capability: AgentCapability, prompt: str
    ) -> Dict[str, Any]:
        """Delegate task to appropriate agent."""
        agent_spec = self.router.find_agent(capability)

        if not agent_spec:
            raise ValueError(f"No agent available for {capability}")

        print(f"  Delegating to {agent_spec.name} ({capability.value})...")

        result = await agent_spec.agent.run(prompt)

        return {
            "agent": agent_spec.name,
            "capability": capability.value,
            "result": result.output,
        }

    async def parallel_delegation(
        self, tasks: List[tuple[AgentCapability, str]]
    ) -> List[Dict[str, Any]]:
        """Execute multiple tasks in parallel."""
        print(f"\n{'─'*60}")
        print(f"Parallel Execution ({len(tasks)} tasks)")
        print(f"{'─'*60}\n")

        results = await asyncio.gather(
            *[self.delegate_task(capability, prompt) for capability, prompt in tasks]
        )

        return results

    async def sequential_delegation(
        self, tasks: List[tuple[AgentCapability, str]], context: Dict[str, Any] = None
    ) -> List[Dict[str, Any]]:
        """Execute tasks sequentially with shared context."""
        # YOUR CODE HERE
        # [SOLUTION]
        context = context or {}
        results = []

        print(f"\n{'─'*60}")
        print(f"Sequential Execution ({len(tasks)} tasks)")
        print(f"{'─'*60}\n")

        for i, (capability, prompt_template) in enumerate(tasks, 1):
            print(f"Task {i}/{len(tasks)}:")

            # Format prompt with context from previous steps
            prompt = prompt_template.format(**context)

            result = await self.delegate_task(capability, prompt)
            results.append(result)

            # Add result to context
            context[f"step_{i}_result"] = result["result"]
            print()

        return results
        # [/SOLUTION]


# Example: Create specialist agents
def create_specialists() -> TaskRouter:
    """Create a team of specialist agents."""
    router = TaskRouter()

    # Research specialist
    research_agent = Agent(
        os.getenv("AI_MODEL", "openai:gpt-5.4-mini"),
        system_prompt="""You are a research specialist.
        Provide detailed, well-researched information with citations where appropriate.""",
    )

    router.register_agent(
        AgentSpec(
            name="ResearchBot",
            capabilities=[AgentCapability.RESEARCH],
            agent=research_agent,
            performance_score=0.9,
        )
    )

    # Writing specialist
    writing_agent = Agent(
        os.getenv("AI_MODEL", "openai:gpt-5.4-mini"),
        system_prompt="""You are a professional writer.
        Create clear, engaging, well-structured content.""",
    )

    router.register_agent(
        AgentSpec(
            name="WriterBot",
            capabilities=[AgentCapability.WRITING],
            agent=writing_agent,
            performance_score=0.95,
        )
    )

    # Analysis specialist
    analysis_agent = Agent(
        os.getenv("AI_MODEL", "openai:gpt-5.4-mini"),
        system_prompt="""You are a data analyst.
        Analyze information critically and provide insights.""",
    )

    router.register_agent(
        AgentSpec(
            name="AnalystBot",
            capabilities=[AgentCapability.ANALYSIS],
            agent=analysis_agent,
            performance_score=0.85,
        )
    )

    # Summarization specialist
    summary_agent = Agent(
        os.getenv("AI_MODEL", "openai:gpt-5.4-mini"),
        system_prompt="""You are a summarization expert.
        Create concise, accurate summaries.""",
    )

    router.register_agent(
        AgentSpec(
            name="SummaryBot",
            capabilities=[AgentCapability.SUMMARIZATION],
            agent=summary_agent,
            performance_score=0.9,
        )
    )

    return router


# Example workflows
async def parallel_research_example():
    """Research multiple topics in parallel."""
    print("\n" + "=" * 60)
    print("  Example: Parallel Research")
    print("=" * 60)

    router = create_specialists()
    coordinator = MultiAgentCoordinator(router)

    topics = [
        "artificial intelligence trends",
        "climate change impacts",
        "quantum computing advances",
    ]

    tasks = [(AgentCapability.RESEARCH, f"Research: {topic}") for topic in topics]

    results = await coordinator.parallel_delegation(tasks)

    print("\n" + "=" * 60)
    print("  Results")
    print("=" * 60)

    for i, result in enumerate(results, 1):
        print(f"\nTopic {i}: {topics[i-1]}")
        print(f"Agent: {result['agent']}")
        print(f"Summary: {result['result'][:150]}...")


async def sequential_report_example():
    """Generate report through sequential delegation."""
    print("\n" + "=" * 60)
    print("  Example: Sequential Report Generation")
    print("=" * 60)

    router = create_specialists()
    coordinator = MultiAgentCoordinator(router)

    tasks = [
        (AgentCapability.RESEARCH, "Research the topic: {topic}"),
        (AgentCapability.ANALYSIS, "Analyze this research: {step_1_result}"),
        (AgentCapability.WRITING, "Write an article based on: {step_2_result}"),
        (AgentCapability.SUMMARIZATION, "Summarize: {step_3_result}"),
    ]

    results = await coordinator.sequential_delegation(
        tasks, context={"topic": "renewable energy"}
    )

    print("\n" + "=" * 60)
    print("  Final Report")
    print("=" * 60)
    print(results[-1]["result"])


async def main():
    """Main demonstrations."""
    await parallel_research_example()
    await sequential_report_example()


if __name__ == "__main__":
    asyncio.run(main())
