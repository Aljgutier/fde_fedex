# Multi-Agent Task Delegation - Solution

Coordinate multiple specialist agents for complex tasks.

## Features

- Task routing to specialist agents
- Parallel and sequential execution
- Agent capability management
- Performance-based selection

## Quick Start

```bash
cp .env.example .env
uv sync
uv run python multi_agent.py
```

Educational use - GAI-2109.
