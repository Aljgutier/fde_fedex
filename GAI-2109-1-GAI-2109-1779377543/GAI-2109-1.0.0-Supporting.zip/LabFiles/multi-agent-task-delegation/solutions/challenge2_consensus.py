"""
Lab Solution: Challenge 2 — Consensus System

Adds a `ConsensusCoordinator` that runs the same prompt through several
specialists with the same capability and hands the individual responses
to a combiner agent for reconciliation. Two patterns this exercises:

* fan-out: identical prompt to N voters in parallel via asyncio.gather
* combine: a dedicated combiner agent merges N free-form answers into
  one consensus response

Run: python challenge2_consensus.py
"""

import asyncio
import os
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from dotenv import load_dotenv
from pydantic_ai import Agent

# Reuse the Challenge-1 balanced router so we have multiple specialists
# advertising the same capability — consensus is most interesting when
# more than one agent can answer the same question.
from challenge1_round_robin import create_balanced_specialists
from multi_agent import (
    AgentCapability,
    AgentSpec,
    MultiAgentCoordinator,
)

load_dotenv()


@dataclass
class ConsensusResult:
    """Carries both the individual votes and the combined output.

    Returning both lets callers do their own analytics on the votes
    (latency stats, disagreement detection, voting margins) without
    re-running the fan-out.
    """

    capability: str
    prompt: str
    individual_responses: List[Dict[str, Any]]  # [{agent, capability, result}, ...]
    consensus: str
    combiner_agent: str


class ConsensusCoordinator(MultiAgentCoordinator):
    """Coordinator with consensus-style multi-voter delegation."""

    def __init__(
        self,
        router,
        combiner_agent: Optional[Agent] = None,
        combiner_name: str = "ConsensusCombiner",
    ):
        super().__init__(router)
        # Default combiner: a summarizer-style agent. Callers can pass
        # their own (e.g., a dedicated voting/judging agent) without
        # touching the rest of the coordinator.
        self.combiner_agent = combiner_agent or Agent(
            os.getenv("AI_MODEL", "openai:gpt-5.4-mini"),
            system_prompt=(
                "You synthesize multiple expert responses into a single "
                "consensus answer. When responses agree, capture the shared "
                "claim concisely. When they disagree, name the disagreement "
                "and present a balanced consensus that integrates the strongest "
                "points from each. Do not exceed 200 words."
            ),
        )
        self.combiner_name = combiner_name

    def _candidates(self, capability: AgentCapability) -> List[AgentSpec]:
        """All specialists registered for the requested capability."""
        return [
            spec
            for spec in self.router.agents.values()
            if capability in spec.capabilities
        ]

    async def consensus_delegation(
        self,
        capability: AgentCapability,
        prompt: str,
        n_voters: Optional[int] = None,
    ) -> ConsensusResult:
        """Delegate the same prompt to N specialists, then combine.

        Args:
            capability: Which capability the voters must advertise.
            prompt: The prompt sent to every voter.
            n_voters: How many voters to use. When ``None``, every
                registered specialist for the capability participates.
                When greater than the number of available candidates,
                we cap silently rather than raise — consensus on three
                voters is still valid even if you asked for five.

        Returns:
            A ConsensusResult carrying the individual votes and the
            combiner's reconciled output.

        Raises:
            ValueError if no specialist advertises the capability or if
            fewer than two voters would participate (consensus among
            one voter is just delegation).
        """
        candidates = self._candidates(capability)
        if not candidates:
            raise ValueError(
                f"No agents registered for {capability.name} — "
                f"register at least two before requesting consensus."
            )
        if n_voters is None or n_voters > len(candidates):
            n_voters = len(candidates)
        if n_voters < 2:
            raise ValueError(
                "Consensus requires at least 2 voters; "
                f"only {n_voters} candidate(s) available for {capability.name}."
            )
        voters = candidates[:n_voters]

        print(f"\n{'─' * 60}")
        print(
            f"Consensus on {capability.value} "
            f"({len(voters)} voters: {', '.join(v.name for v in voters)})"
        )
        print(f"{'─' * 60}")
        print(f"Prompt: {prompt}\n")

        # Fan out: run all voters in parallel. Each voter sees the same
        # prompt — what differs is the agent's system prompt and any
        # latent variation in its training/sampling.
        async def run_voter(spec: AgentSpec) -> Dict[str, Any]:
            print(f"  Soliciting vote from {spec.name}...")
            result = await spec.agent.run(prompt)
            return {
                "agent": spec.name,
                "capability": capability.value,
                "result": result.output,
            }

        individual_responses = await asyncio.gather(
            *(run_voter(spec) for spec in voters)
        )

        # Combine: hand the structured list to the combiner. We render
        # the votes as a numbered transcript so the combiner can refer
        # to them ("voter 1 claims X, voter 2 claims Y, the consensus is...").
        transcript_lines = [f"Original question: {prompt}", "", "Voter responses:"]
        for i, vote in enumerate(individual_responses, 1):
            transcript_lines.append(f"\n[Voter {i} — {vote['agent']}]")
            transcript_lines.append(vote["result"])
        transcript = "\n".join(transcript_lines)

        combiner_prompt = (
            f"{transcript}\n\n"
            "Synthesize a single consensus response. Highlight any "
            "disagreements between voters and integrate the strongest "
            "points from each."
        )
        print(f"\n  Combining via {self.combiner_name}...")
        combiner_result = await self.combiner_agent.run(combiner_prompt)

        return ConsensusResult(
            capability=capability.value,
            prompt=prompt,
            individual_responses=individual_responses,
            consensus=combiner_result.output,
            combiner_agent=self.combiner_name,
        )


def print_consensus(result: ConsensusResult) -> None:
    """Render a ConsensusResult in a readable form."""
    print(f"\n{'=' * 60}")
    print(f"  Consensus Result — capability: {result.capability}")
    print(f"{'=' * 60}")

    print("\n--- Individual votes ---")
    for i, vote in enumerate(result.individual_responses, 1):
        print(f"\n[Voter {i}: {vote['agent']}]")
        # Truncate long answers for display only — the full answer is
        # in the dataclass for callers that want to do their own analysis.
        snippet = vote["result"][:300]
        if len(vote["result"]) > 300:
            snippet += "..."
        print(f"  {snippet}")

    print(f"\n--- Consensus (via {result.combiner_agent}) ---")
    print(f"  {result.consensus}")
    print()


async def main() -> None:
    print("=" * 60)
    print("  CHALLENGE 2 — Multi-Voter Consensus")
    print("=" * 60)

    # Use the balanced router so RESEARCH has two voters available.
    router = create_balanced_specialists()
    coordinator = ConsensusCoordinator(router)

    # Factual question — voters should agree, consensus should match
    # the majority claim.
    factual = await coordinator.consensus_delegation(
        capability=AgentCapability.RESEARCH,
        prompt=(
            "What is the boiling point of water at sea level, in degrees "
            "Celsius? Reply in one short sentence."
        ),
    )
    print_consensus(factual)

    # Subjective question — voters may differ in framing or emphasis;
    # consensus should integrate multiple perspectives rather than
    # picking one.
    subjective = await coordinator.consensus_delegation(
        capability=AgentCapability.RESEARCH,
        prompt=(
            "What are the most important considerations when choosing a "
            "machine learning framework for a new project? Reply in three "
            "or four sentences."
        ),
    )
    print_consensus(subjective)


if __name__ == "__main__":
    asyncio.run(main())
