"""
Lab Solution: Challenge 1 — Round-Robin Load Balancing

Extends `TaskRouter` so repeated requests for the same capability spread
across all specialists that advertise it, rather than always picking the
top performer. The Core Lab's `find_agent` returns the highest-scoring
candidate every time; this challenge adds a parallel `find_agent_balanced`
that cycles through equivalent specialists deterministically.

Run: python challenge1_round_robin.py
"""

import asyncio
import os
from typing import Dict, Optional

from dotenv import load_dotenv
from pydantic_ai import Agent

from multi_agent import (
    AgentCapability,
    AgentSpec,
    MultiAgentCoordinator,
    TaskRouter,
    create_specialists,
)

load_dotenv()


class BalancedTaskRouter(TaskRouter):
    """TaskRouter with deterministic round-robin selection per capability.

    Adds `find_agent_balanced(capability)` alongside the parent's
    `find_agent`. The two methods coexist deliberately:

    * `find_agent(capability)` keeps its quality- or cost-optimizing
      semantics for one-shot routing where the best-fit specialist is
      what you want.
    * `find_agent_balanced(capability)` is the new method for
      load-balanced batches — it cycles through every candidate that
      advertises the capability, returning the next one each call.
    """

    def __init__(self) -> None:
        super().__init__()
        # Per-capability cursor. We store the index of the LAST agent
        # returned, so each call to find_agent_balanced increments it
        # modulo the number of candidates currently advertising the
        # capability. Using a per-capability cursor keeps RESEARCH
        # rotation independent of WRITING rotation.
        self._last_index: Dict[AgentCapability, int] = {}

    def find_agent_balanced(
        self, capability: AgentCapability
    ) -> Optional[AgentSpec]:
        """Return the next specialist for this capability, round-robin.

        Returns ``None`` if no agent advertises the capability — the
        same null-result contract the parent ``find_agent`` uses.

        Sorting candidates by name keeps the rotation deterministic
        across runs (registration order is dict-insertion order in
        modern Python, but a stable sort makes the contract explicit
        and survives a future refactor of the registry).
        """
        candidates = sorted(
            (spec for spec in self.agents.values() if capability in spec.capabilities),
            key=lambda spec: spec.name,
        )

        if not candidates:
            return None

        last = self._last_index.get(capability, -1)
        next_index = (last + 1) % len(candidates)
        self._last_index[capability] = next_index
        return candidates[next_index]


def create_balanced_specialists() -> BalancedTaskRouter:
    """Build a registry where multiple specialists advertise the same
    capability so round-robin has something to rotate through.

    The Core Lab's create_specialists() registers exactly one agent per
    capability — no rotation is possible. This helper adds a second
    researcher (ResearchBot-B) so that calls to RESEARCH cycle between
    two equivalent specialists.
    """
    # Start from the Core Lab's registry so the four baseline specialists
    # (ResearchBot, WriterBot, AnalystBot, SummaryBot) remain available.
    base = create_specialists()
    router = BalancedTaskRouter()
    for spec in base.agents.values():
        router.register_agent(spec)

    # Rename the original researcher to ResearchBot-A so the rotation is
    # legible in the output, then add a peer ResearchBot-B with the same
    # capability and a different (lower) performance_score — so any
    # quality-optimizing call still picks A while the balanced call
    # cycles A → B → A → B.
    a = router.agents.pop("ResearchBot")
    a.name = "ResearchBot-A"
    router.register_agent(a)

    research_agent_b = Agent(
        os.getenv("AI_MODEL", "openai:gpt-5.4-mini"),
        system_prompt=(
            "You are a research specialist. Provide detailed, well-researched "
            "information with citations where appropriate."
        ),
    )
    router.register_agent(
        AgentSpec(
            name="ResearchBot-B",
            capabilities=[AgentCapability.RESEARCH],
            agent=research_agent_b,
            performance_score=0.85,
            cost_multiplier=0.9,
        )
    )

    return router


async def main() -> None:
    print("=" * 60)
    print("  CHALLENGE 1 — Round-Robin Load Balancing")
    print("=" * 60)

    router = create_balanced_specialists()
    coordinator = MultiAgentCoordinator(router)

    # Demonstrate the rotation: four consecutive calls for RESEARCH should
    # produce the pattern A, B, A, B.
    print("\n--- Rotation across two RESEARCH specialists ---")
    rotation = []
    for i in range(4):
        spec = router.find_agent_balanced(AgentCapability.RESEARCH)
        rotation.append(spec.name)
        print(f"  call {i + 1}: {spec.name} (perf={spec.performance_score})")

    expected = ["ResearchBot-A", "ResearchBot-B", "ResearchBot-A", "ResearchBot-B"]
    if rotation == expected:
        print(f"\n  Rotation pattern: {' -> '.join(rotation)}  (matches A/B/A/B)")
    else:
        print(f"\n  Rotation pattern: {' -> '.join(rotation)} (expected {expected})")

    # Confirm find_agent (quality-optimizing) still picks ResearchBot-A,
    # so the new method is purely additive — it doesn't change the
    # default routing behavior the rest of the lab relies on.
    print("\n--- Quality-optimizing path is unchanged ---")
    quality_pick = router.find_agent(AgentCapability.RESEARCH, prefer_quality=True)
    print(f"  find_agent(RESEARCH, prefer_quality=True) -> {quality_pick.name}")
    assert quality_pick.name == "ResearchBot-A", \
        "Quality routing should still favor the higher-perf specialist"

    # Demonstrate per-capability cursor independence: SUMMARIZATION
    # only has one specialist, so its rotation is trivial — but the
    # RESEARCH cursor is unchanged by an interleaved SUMMARIZATION call.
    print("\n--- Per-capability cursors are independent ---")
    print(f"  next RESEARCH:        {router.find_agent_balanced(AgentCapability.RESEARCH).name}")
    print(f"  next SUMMARIZATION:   {router.find_agent_balanced(AgentCapability.SUMMARIZATION).name}")
    print(f"  next RESEARCH:        {router.find_agent_balanced(AgentCapability.RESEARCH).name}")


if __name__ == "__main__":
    asyncio.run(main())
